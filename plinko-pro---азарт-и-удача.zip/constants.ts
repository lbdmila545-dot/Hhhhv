
import { Multiplier } from './types.ts';

export const CANVAS_WIDTH = 400;
export const CANVAS_HEIGHT = 500;
export const ROWS = 12;
export const PIN_SPACING_X = 32;
export const PIN_SPACING_Y = 32;
export const BALL_RADIUS = 5;
export const PIN_RADIUS = 2.5;
export const GRAVITY = 0.15;
export const FRICTION = 0.99;
export const BOUNCE = 0.5;

export const MULTIPLIERS: Multiplier[] = [
  { value: 13, color: '#ef4444', label: '13' },
  { value: 3, color: '#f97316', label: '3' },
  { value: 1.3, color: '#eab308', label: '1.3' },
  { value: 0.7, color: '#22c55e', label: '0.7' },
  { value: 0.4, color: '#22c55e', label: '0.4' },
  { value: 0.7, color: '#22c55e', label: '0.7' },
  { value: 1.3, color: '#eab308', label: '1.3' },
  { value: 3, color: '#f97316', label: '3' },
  { value: 13, color: '#ef4444', label: '13' },
];

export const INITIAL_BALANCE = 1000;
export const MIN_BET = 10;
export const MAX_BET = 1000;