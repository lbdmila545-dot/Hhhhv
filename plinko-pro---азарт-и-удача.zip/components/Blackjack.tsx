
import React, { useState } from 'react';

interface BlackjackProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Blackjack: React.FC<BlackjackProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playerHand, setPlayerHand] = useState<number[]>([]);
  const [dealerHand, setDealerHand] = useState<number[]>([]);
  const [status, setStatus] = useState<string>('');

  const getCardValue = () => Math.floor(Math.random() * 10) + 1;

  const calculateTotal = (hand: number[]) => hand.reduce((a, b) => a + b, 0);

  const startDeal = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setStatus('');
    const p1 = getCardValue();
    const p2 = getCardValue();
    const d1 = getCardValue();
    setPlayerHand([p1, p2]);
    setDealerHand([d1]);
  };

  const hit = () => {
    const next = getCardValue();
    const newHand = [...playerHand, next];
    setPlayerHand(newHand);
    if (calculateTotal(newHand) > 21) {
      setStatus('ПЕРЕБОР! ПРОИГРЫШ');
      setIsPlaying(false);
    }
  };

  const stand = () => {
    let dHand = [...dealerHand];
    while (calculateTotal(dHand) < 17) {
      dHand.push(getCardValue());
    }
    setDealerHand(dHand);
    
    const pTotal = calculateTotal(playerHand);
    const dTotal = calculateTotal(dHand);
    
    if (dTotal > 21 || pTotal > dTotal) {
      setStatus('ПОБЕДА!');
      onBalanceChange(bet * 2);
    } else if (pTotal === dTotal) {
      setStatus('НИЧЬЯ');
      onBalanceChange(bet);
    } else {
      setStatus('ПРОИГРЫШ');
    }
    setIsPlaying(false);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0a2a] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-blue-500 uppercase">BLACKJACK</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-12">
        <div className="flex flex-col items-center gap-4">
           <span className="text-[10px] uppercase font-black text-slate-500">ДИЛЕР ({calculateTotal(dealerHand)})</span>
           <div className="flex gap-2">
              {dealerHand.map((c, i) => <div key={i} className="w-12 h-16 bg-white rounded-lg flex items-center justify-center text-black font-black">{c}</div>)}
           </div>
        </div>

        <div className="text-2xl font-black uppercase text-yellow-500 animate-pulse">{status}</div>

        <div className="flex flex-col items-center gap-4">
           <span className="text-[10px] uppercase font-black text-slate-500">ИГРОК ({calculateTotal(playerHand)})</span>
           <div className="flex gap-2">
              {playerHand.map((c, i) => <div key={i} className="w-12 h-16 bg-blue-600 rounded-lg flex items-center justify-center text-white font-black border-2 border-blue-400">{c}</div>)}
           </div>
        </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4 shadow-2xl">
        {!isPlaying ? (
          <>
            <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value))} className="w-full bg-black/40 p-4 rounded-2xl border border-slate-800 text-center font-black" />
            <button onClick={startDeal} className="w-full h-16 bg-blue-600 rounded-2xl font-black uppercase">ИГРАТЬ</button>
          </>
        ) : (
          <div className="flex gap-4">
             <button onClick={hit} className="flex-1 h-16 bg-green-600 rounded-2xl font-black uppercase">ЕЩЕ</button>
             <button onClick={stand} className="flex-1 h-16 bg-red-600 rounded-2xl font-black uppercase">СТОП</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Blackjack;
