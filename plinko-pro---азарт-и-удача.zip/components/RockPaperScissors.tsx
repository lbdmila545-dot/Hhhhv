
import React, { useState } from 'react';

interface RockPaperScissorsProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

type Move = 'ROCK' | 'PAPER' | 'SCISSORS';

const RockPaperScissors: React.FC<RockPaperScissorsProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [botMove, setBotMove] = useState<Move | null>(null);

  const play = (playerMove: Move) => {
    if (balance < bet || isPlaying) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setResult(null);
    setBotMove(null);

    setTimeout(() => {
      const moves: Move[] = ['ROCK', 'PAPER', 'SCISSORS'];
      const bMove = moves[Math.floor(Math.random() * 3)];
      setBotMove(bMove);

      if (playerMove === bMove) {
        onBalanceChange(bet); // Возврат ставки при ничьей
        setResult('НИЧЬЯ');
      } else if (
        (playerMove === 'ROCK' && bMove === 'SCISSORS') ||
        (playerMove === 'PAPER' && bMove === 'ROCK') ||
        (playerMove === 'SCISSORS' && bMove === 'PAPER')
      ) {
        onBalanceChange(bet * 2);
        setResult('ПОБЕДА! x2');
      } else {
        setResult('ПРОИГРЫШ');
      }
      setIsPlaying(false);
    }, 800);
  };

  const icons = { ROCK: 'fa-hand-back-fist', PAPER: 'fa-hand', SCISSORS: 'fa-hand-scissors' };

  return (
    <div className="flex flex-col h-full w-full bg-[#1a1a1a] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-slate-400">ROCK PAPER SCISSORS</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-around">
        <div className="flex flex-col items-center">
            <span className="text-[10px] text-slate-500 font-black uppercase mb-4 tracking-widest">ВЫБОР КАЗИНО</span>
            <div className={`w-24 h-24 bg-slate-800 rounded-3xl border-4 border-slate-700 flex items-center justify-center text-4xl transition-all ${isPlaying ? 'animate-bounce' : ''}`}>
               {botMove ? <i className={`fas ${icons[botMove]} text-white`}></i> : <i className="fas fa-question text-slate-500"></i>}
            </div>
        </div>

        {result && <div className={`text-4xl font-black italic uppercase ${result.includes('ПОБЕДА') ? 'text-green-400' : result === 'НИЧЬЯ' ? 'text-yellow-500' : 'text-red-500'}`}>{result}</div>}

        <div className="flex gap-4 w-full">
            {(['ROCK', 'PAPER', 'SCISSORS'] as Move[]).map(move => (
                <button key={move} onClick={() => play(move)} disabled={isPlaying} className="flex-1 aspect-square bg-slate-800 rounded-2xl border-2 border-slate-700 hover:border-blue-500 transition-all flex items-center justify-center text-3xl active:scale-90">
                    <i className={`fas ${icons[move]} text-blue-400`}></i>
                </button>
            ))}
        </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] mt-6">
        <div className="flex justify-between items-center bg-black/40 p-4 rounded-2xl">
           <button onClick={() => setBet(Math.max(10, bet-10))} disabled={isPlaying} className="text-blue-500 text-2xl font-black">-</button>
           <div className="flex flex-col items-center">
             <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">СТАВКА</span>
             <span className="font-black">{bet} RUB</span>
           </div>
           <button onClick={() => setBet(bet+10)} disabled={isPlaying} className="text-blue-500 text-2xl font-black">+</button>
        </div>
      </div>
    </div>
  );
};

export default RockPaperScissors;
