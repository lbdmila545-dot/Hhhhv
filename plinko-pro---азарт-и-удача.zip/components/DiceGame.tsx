
import React, { useState } from 'react';

interface DiceGameProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const DiceGame: React.FC<DiceGameProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isRolling, setIsRolling] = useState(false);
  const [dice, setDice] = useState([1, 1]);
  const [choice, setChoice] = useState<'UNDER' | 'OVER' | 'EXACT'>('UNDER');
  const [message, setMessage] = useState<string | null>(null);

  const rollDice = () => {
    if (isRolling || balance < bet) return;
    onBalanceChange(-bet);
    setIsRolling(true);
    setMessage(null);

    const rollDuration = 1000;
    const interval = setInterval(() => {
      setDice([Math.floor(Math.random() * 6) + 1, Math.floor(Math.random() * 6) + 1]);
    }, 100);

    setTimeout(() => {
      clearInterval(interval);
      const finalDice = [Math.floor(Math.random() * 6) + 1, Math.floor(Math.random() * 6) + 1];
      setDice(finalDice);
      const sum = finalDice[0] + finalDice[1];
      
      let win = false;
      let multiplier = 2.3;

      if (choice === 'UNDER' && sum < 7) win = true;
      if (choice === 'OVER' && sum > 7) win = true;
      if (choice === 'EXACT' && sum === 7) {
        win = true;
        multiplier = 5.8;
      }

      if (win) {
        const winAmt = Math.floor(bet * multiplier);
        onBalanceChange(winAmt);
        setMessage(`ВЫИГРЫШ: +${winAmt} RUB!`);
      } else {
        setMessage('ПРОИГРЫШ');
      }

      setIsRolling(false);
    }, rollDuration);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0a1a] text-white">
      <div className="flex justify-between items-center p-4 bg-indigo-950/40 border-b border-indigo-500/20">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center active:scale-90">
            <i className="fas fa-arrow-left"></i>
        </button>
        <span className="font-black italic uppercase text-indigo-400 tracking-tighter">DICE CLASSIC</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="flex gap-8 mb-12">
          {dice.map((d, i) => (
            <div key={i} className={`w-24 h-24 bg-white rounded-3xl flex items-center justify-center text-4xl text-indigo-950 font-black shadow-[0_10px_0_#cbd5e1] border-2 border-slate-100 ${isRolling ? 'animate-bounce' : ''}`}>
              {d}
            </div>
          ))}
        </div>

        <div className="h-20 flex flex-col items-center justify-center">
            <div className="text-4xl font-black text-white mb-2">{dice[0] + dice[1]}</div>
            {message && <div className={`text-xl font-black uppercase tracking-widest ${message.includes('ВЫИГРЫШ') ? 'text-green-400 animate-pulse' : 'text-red-500'}`}>{message}</div>}
        </div>

        <div className="grid grid-cols-3 gap-3 w-full max-w-sm mt-12">
            <button 
                onClick={() => setChoice('UNDER')}
                className={`py-6 rounded-2xl font-black flex flex-col items-center transition-all ${choice === 'UNDER' ? 'bg-indigo-600 shadow-xl border-indigo-400' : 'bg-slate-800 border-slate-700'}`}
            >
                <span className="text-xs opacity-60">МЕНЬШЕ 7</span>
                <span className="text-lg">x2.3</span>
            </button>
            <button 
                onClick={() => setChoice('EXACT')}
                className={`py-6 rounded-2xl font-black flex flex-col items-center transition-all ${choice === 'EXACT' ? 'bg-indigo-600 shadow-xl border-indigo-400' : 'bg-slate-800 border-slate-700'}`}
            >
                <span className="text-xs opacity-60">РАВНО 7</span>
                <span className="text-lg">x5.8</span>
            </button>
            <button 
                onClick={() => setChoice('OVER')}
                className={`py-6 rounded-2xl font-black flex flex-col items-center transition-all ${choice === 'OVER' ? 'bg-indigo-600 shadow-xl border-indigo-400' : 'bg-slate-800 border-slate-700'}`}
            >
                <span className="text-xs opacity-60">БОЛЬШЕ 7</span>
                <span className="text-lg">x2.3</span>
            </button>
        </div>
      </div>

      <div className="p-8 bg-slate-900 rounded-t-[40px] space-y-6">
        <div className="flex items-center justify-between bg-black/40 p-4 rounded-3xl border border-slate-800">
            <button onClick={() => setBet(Math.max(10, bet - 10))} className="text-indigo-400 font-black text-2xl px-4">-</button>
            <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">СТАВКА</span>
                <span className="text-xl font-black">{bet} RUB</span>
            </div>
            <button onClick={() => setBet(bet + 10)} className="text-indigo-400 font-black text-2xl px-4">+</button>
        </div>
        <button 
            onClick={rollDice}
            disabled={isRolling || balance < bet}
            className="w-full h-16 bg-gradient-to-r from-indigo-500 to-blue-600 rounded-2xl font-black uppercase shadow-xl shadow-indigo-900/40 active:scale-95"
        >
            {isRolling ? 'БРОСОК...' : 'БРОСИТЬ КУБИКИ'}
        </button>
      </div>
    </div>
  );
};

export default DiceGame;
