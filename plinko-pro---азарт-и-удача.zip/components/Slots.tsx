
import React, { useState, useRef } from 'react';

interface SlotsProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const SYMBOLS = ['🍒', '🍋', '🍇', '💎', '🔔', '7️⃣'];
const REEL_SIZE = 3;

const Slots: React.FC<SlotsProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [reels, setReels] = useState<string[][]>([
    ['💎', '7️⃣', '🍒'],
    ['🔔', '💎', '🍇'],
    ['🍒', '🍇', '7️⃣']
  ]);
  const [isSpinning, setIsSpinning] = useState(false);
  const [winMessage, setWinMessage] = useState<string | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playSound = (type: 'spin' | 'win' | 'stop') => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === 'spin') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(200, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(400, ctx.currentTime + 1);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1);
    } else if (type === 'win') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1046, ctx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
    } else {
      osc.type = 'square';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      gain.gain.setValueAtTime(0.02, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.1);
    }

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 1);
  };

  const spin = () => {
    if (balance < bet || isSpinning) return;
    initAudio();
    onBalanceChange(-bet);
    setIsSpinning(true);
    setWinMessage(null);
    playSound('spin');

    const spinDuration = 2000;
    const interval = setInterval(() => {
        setReels(reels.map(() => 
            Array(REEL_SIZE).fill(0).map(() => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)])
        ));
    }, 100);

    setTimeout(() => {
        clearInterval(interval);
        const finalReels = reels.map(() => 
            Array(REEL_SIZE).fill(0).map(() => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)])
        );
        setReels(finalReels);
        checkWins(finalReels);
        setIsSpinning(false);
        playSound('stop');
    }, spinDuration);
  };

  const checkWins = (currentReels: string[][]) => {
    let winCount = 0;
    // Check horizontal lines
    for (let r = 0; r < REEL_SIZE; r++) {
        if (currentReels[0][r] === currentReels[1][r] && currentReels[1][r] === currentReels[2][r]) {
            winCount += 1;
        }
    }
    // Simple logic: if symbols match across reels in middle row
    if (winCount > 0) {
        const winAmount = bet * 10 * winCount;
        onBalanceChange(winAmount);
        setWinMessage(`ВЫИГРЫШ: +${winAmount} RUB`);
        playSound('win');
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#1a0f1f] relative overflow-hidden">
      <div className="flex justify-between items-center p-4 bg-purple-900/30 border-b border-purple-500/20 z-20">
        <button onClick={onBack} className="w-10 h-10 bg-purple-600/20 rounded-full flex items-center justify-center">
            <i className="fas fa-arrow-left text-white text-sm"></i>
        </button>
        <span className="text-sm font-black uppercase text-purple-400">GRAND SLOTS</span>
        <div className="w-10" />
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div className="bg-purple-900/40 p-4 rounded-3xl border-4 border-purple-600 shadow-[0_0_50px_rgba(147,51,234,0.3)] relative">
            <div className="flex gap-2">
                {reels.map((reel, rIdx) => (
                    <div key={rIdx} className="w-20 h-48 bg-black/60 rounded-xl overflow-hidden flex flex-col gap-2 p-2 border border-purple-500/20">
                        {reel.map((symbol, sIdx) => (
                            <div key={sIdx} className="h-14 flex items-center justify-center text-3xl animate-in fade-in zoom-in duration-300">
                                {symbol}
                            </div>
                        ))}
                    </div>
                ))}
            </div>
            {/* Payline */}
            <div className="absolute top-1/2 left-0 w-full h-1 bg-white/20 -translate-y-1/2 pointer-events-none"></div>
        </div>

        {winMessage && (
            <div className="mt-8 text-2xl font-black text-yellow-400 animate-pulse uppercase">
                {winMessage}
            </div>
        )}
      </div>

      <div className="p-6 bg-black/90 border-t border-purple-900/40">
        <div className="flex flex-col gap-4 max-w-md mx-auto">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <button onClick={() => setBet(Math.max(10, bet-10))} className="w-10 h-10 bg-purple-600/20 rounded-full text-purple-400 font-bold">-</button>
                    <div className="px-6 py-2 bg-black/40 rounded-xl border border-purple-500/20 font-black text-white">
                        {bet} RUB
                    </div>
                    <button onClick={() => setBet(bet+10)} className="w-10 h-10 bg-purple-600/20 rounded-full text-purple-400 font-bold">+</button>
                </div>
                <button onClick={() => setBet(Math.floor(balance))} className="px-4 py-2 bg-purple-600/20 rounded-xl text-xs font-bold text-purple-400">MAX</button>
            </div>

            <button 
                onClick={spin}
                disabled={isSpinning || balance < bet}
                className={`w-full h-16 rounded-2xl font-black text-white uppercase tracking-widest shadow-xl transition-all ${
                    isSpinning ? 'bg-purple-900/50 grayscale cursor-not-allowed' : 'bg-gradient-to-r from-purple-500 to-pink-600 active:scale-95'
                }`}
            >
                {isSpinning ? 'ВРАЩЕНИЕ...' : 'ИГРАТЬ'}
            </button>
        </div>
      </div>
    </div>
  );
};

export default Slots;
