
import React, { useState, useCallback, useRef, useEffect } from 'react';

interface AppleOfFortuneProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

// Множители для игры
const MULTIPLIERS = [349.68, 69.93, 27.97, 11.18, 6.71, 4.02, 2.41, 1.93, 1.54, 1.23];

const ASSETS = {
  APPLE: 'https://cdn-icons-png.flaticon.com/512/415/415733.png',
  STRAWBERRY: 'https://cdn-icons-png.flaticon.com/512/590/590685.png', // Клубника вместо огрызка
  WOOD_PATTERN: 'https://www.transparenttextures.com/patterns/wood-pattern.png',
  BG_ART: 'https://images.unsplash.com/photo-1570169797700-182bc8a609dc?auto=format&fit=crop&q=80&w=800'
};

const AppleOfFortune: React.FC<AppleOfFortuneProps> = ({ balance, onBalanceChange, onBack }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [bet, setBet] = useState(10);
  const [currentRow, setCurrentRow] = useState(-1);
  const [grid, setGrid] = useState<any[][]>(() => 
    Array(MULTIPLIERS.length).fill(null).map(() => Array(5).fill(null))
  );
  const [gameStatus, setGameStatus] = useState<'IDLE' | 'PLAYING' | 'WIN' | 'LOSE'>('IDLE');
  const [lastMessage, setLastMessage] = useState<string>('');
  
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playSound = (type: 'wood_break' | 'success' | 'strawberry_fail' | 'click') => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === 'wood_break') {
      // Имитация треска дерева
      osc.type = 'square';
      osc.frequency.setValueAtTime(120, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.15);
    } else if (type === 'success') {
      // Победный звон
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
    } else if (type === 'strawberry_fail') {
      // Драматичный проигрыш
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(30, ctx.currentTime + 0.8);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.8);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.05);
    }

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + (type === 'strawberry_fail' ? 0.8 : 0.3));
  };

  useEffect(() => {
    if (isPlaying && scrollContainerRef.current) {
      const activeElement = scrollContainerRef.current.querySelector('.active-row');
      if (activeElement) {
        activeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [currentRow, isPlaying]);

  const generateRow = useCallback(() => {
    const items: ('apple' | 'core')[] = Array(5).fill('apple');
    // С ростом уровня увеличиваем количество клубник (ловушек)
    const coreCount = currentRow < 3 ? 1 : (currentRow < 6 ? 2 : 3);
    const indices = [0, 1, 2, 3, 4];
    for (let i = 0; i < coreCount; i++) {
        const randomIndex = Math.floor(Math.random() * indices.length);
        const idx = indices.splice(randomIndex, 1)[0];
        items[idx] = 'core';
    }
    return items;
  }, [currentRow]);

  const startGame = () => {
    initAudio();
    if (balance < bet) {
        alert("Недостаточно средств. Заберите бонус на главной!");
        return;
    }
    if (bet < 10) {
      alert("Минимальная ставка 10 RUB");
      return;
    }
    playSound('click');
    onBalanceChange(-bet); // Ставка забирается БК сразу
    setIsPlaying(true);
    setCurrentRow(0);
    setGameStatus('PLAYING');
    setLastMessage('');
    setGrid(Array(MULTIPLIERS.length).fill(null).map(() => Array(5).fill(null)));
  };

  const handleTileClick = (rowIndex: number, colIndex: number) => {
    const actualRowIndexFromBottom = MULTIPLIERS.length - 1 - rowIndex;
    if (!isPlaying || actualRowIndexFromBottom !== currentRow || grid[rowIndex][colIndex] !== null) return;

    playSound('wood_break');
    const items = generateRow();
    const result = items[colIndex];
    const newGrid = [...grid];
    const rowToUpdate = [...grid[rowIndex]];
    rowToUpdate[colIndex] = result;
    newGrid[rowIndex] = rowToUpdate;
    setGrid(newGrid);

    if (result === 'apple') {
      playSound('success');
      if (currentRow === MULTIPLIERS.length - 1) {
        const winAmount = bet * MULTIPLIERS[0];
        setGameStatus('WIN');
        setLastMessage(`JACKPOT: ${winAmount.toFixed(0)} RUB!`);
        onBalanceChange(winAmount);
        setIsPlaying(false);
      } else {
        setCurrentRow(prev => prev + 1);
      }
    } else {
      playSound('strawberry_fail');
      setGameStatus('LOSE');
      setLastMessage('ПРОИГРЫШ (КЛУБНИКА)');
      setIsPlaying(false);
      // При проигрыше ставка остается у БК (уже списана)
      // Раскрываем все в этом ряду для честности
      const finalGrid = [...newGrid];
      finalGrid[rowIndex] = items;
      setGrid(finalGrid);
    }
  };

  const takeWin = () => {
    if (currentRow <= 0) return;
    playSound('success');
    const currentMult = MULTIPLIERS[MULTIPLIERS.length - currentRow];
    const winAmount = bet * currentMult;
    onBalanceChange(winAmount);
    setGameStatus('WIN');
    setLastMessage(`ВЫИГРЫШ: ${winAmount.toFixed(0)} RUB`);
    setIsPlaying(false);
    setCurrentRow(-1);
  };

  const handleBetChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value) || 0;
    setBet(val);
  };

  const handleBetBlur = () => {
    const validBet = Math.max(10, Math.min(balance, bet));
    setBet(validBet);
  };

  const quickBet = (type: 'min' | 'half' | 'double' | 'max') => {
    if (isPlaying) return;
    playSound('click');
    let newBet = bet;
    switch(type) {
      case 'min': newBet = 10; break;
      case 'half': newBet = Math.max(10, Math.floor(bet / 2)); break;
      case 'double': newBet = Math.min(balance, bet * 2); break;
      case 'max': newBet = Math.floor(balance); break;
    }
    setBet(newBet);
  };

  return (
    <div className="flex flex-col h-full relative overflow-hidden bg-[#0c0606]">
      <div className="absolute inset-0 z-0">
         <img src={ASSETS.BG_ART} className="w-full h-full object-cover opacity-30" alt="" />
         <div className="absolute inset-0 bg-gradient-to-t from-[#0c0606] via-transparent to-[#0c0606]"></div>
      </div>
      
      <div className="flex justify-between items-center p-4 bg-black/70 border-b border-orange-900/40 z-20">
        <button onClick={onBack} className="w-10 h-10 bg-orange-900/40 rounded-full flex items-center justify-center border border-orange-600/50 shadow-lg active:scale-95 transition-transform">
            <i className="fas fa-arrow-left text-white text-sm"></i>
        </button>
        <span className="text-sm font-black italic uppercase text-white tracking-widest">APPLE OF FORTUNE</span>
        <div className="w-10" />
      </div>

      <div ref={scrollContainerRef} className="flex-1 overflow-y-auto px-4 pt-12 pb-24 z-10 no-scrollbar flex flex-col items-center">
        <div className="w-full max-w-[320px] bg-[#3d2517]/60 p-1.5 rounded-xl border-[4px] border-[#5d3a1a] shadow-[0_0_50px_rgba(0,0,0,0.8)] relative">
          <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-[#1a0f0f] px-6 py-1.5 rounded-lg border border-orange-800 z-30 min-w-[180px] text-center shadow-xl">
             <span className="text-[10px] font-black uppercase text-orange-500 tracking-tighter">
                {lastMessage || (isPlaying ? 'ГДЕ ЯБЛОКО?' : 'СДЕЛАЙТЕ СТАВКУ')}
             </span>
          </div>

          <div className="flex flex-col gap-1.5 mt-4">
            {MULTIPLIERS.map((mult, rIdx) => {
              const gameRowIdxFromBottom = MULTIPLIERS.length - 1 - rIdx;
              const isActive = isPlaying && gameRowIdxFromBottom === currentRow;
              return (
                <div key={rIdx} className={`flex gap-1.5 h-12 relative transition-all duration-300 ${isActive ? 'active-row scale-[1.03] z-20' : ''}`}>
                  {Array(5).fill(0).map((_, cIdx) => {
                    const cellValue = grid[rIdx] ? grid[rIdx][cIdx] : null;
                    return (
                      <button
                        key={cIdx}
                        onClick={() => handleTileClick(rIdx, cIdx)}
                        disabled={!isActive}
                        className={`flex-1 rounded-md border border-white/5 flex items-center justify-center relative transition-all duration-300
                          ${cellValue === 'apple' ? 'bg-green-600/30 ring-1 ring-green-500/50 shadow-inner' : ''}
                          ${cellValue === 'core' ? 'bg-red-600/30 ring-1 ring-red-500/50' : ''}
                          ${!cellValue ? 'bg-[#5c3c26] hover:bg-[#6e4830]' : ''}
                          ${!isActive && !cellValue ? 'opacity-40 grayscale-[0.3]' : ''}
                        `}
                      >
                         {cellValue === 'apple' && <img src={ASSETS.APPLE} className="w-8 h-8 animate-in zoom-in duration-300 drop-shadow-md" />}
                         {cellValue === 'core' && <img src={ASSETS.STRAWBERRY} className="w-8 h-8 animate-in zoom-in duration-300 drop-shadow-md" />}
                         {isActive && !cellValue && (
                            <div className="absolute inset-0 bg-yellow-400/5 animate-pulse rounded-md"></div>
                         )}
                         <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')]"></div>
                      </button>
                    );
                  })}
                  <div className={`w-16 flex items-center justify-center rounded-md text-[10px] font-black border transition-colors ${isActive ? 'bg-orange-500 text-white border-white/30 shadow-lg' : 'bg-black/40 text-slate-500 border-white/5'}`}>
                    x{mult.toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="p-4 bg-black/95 border-t border-orange-900/30 z-30 space-y-3 shadow-[0_-10px_30px_rgba(0,0,0,0.8)]">
        {/* Панель быстрых ставок */}
        <div className="flex gap-1.5 max-w-md mx-auto h-8">
           <button onClick={() => quickBet('min')} disabled={isPlaying} className="flex-1 bg-zinc-800 rounded text-[9px] font-black hover:bg-zinc-700 disabled:opacity-50 text-slate-400">МИН</button>
           <button onClick={() => quickBet('half')} disabled={isPlaying} className="flex-1 bg-zinc-800 rounded text-[9px] font-black hover:bg-zinc-700 disabled:opacity-50 text-slate-400">1/2</button>
           <button onClick={() => quickBet('double')} disabled={isPlaying} className="flex-1 bg-zinc-800 rounded text-[9px] font-black hover:bg-zinc-700 disabled:opacity-50 text-slate-400 underline underline-offset-2 decoration-orange-500">x2</button>
           <button onClick={() => quickBet('max')} disabled={isPlaying} className="flex-1 bg-zinc-800 rounded text-[9px] font-black hover:bg-zinc-700 disabled:opacity-50 text-slate-400">МАКС</button>
        </div>

        <div className="flex items-center gap-3 max-w-md mx-auto">
          <div className="flex-1 bg-[#1a0f0f] p-2 rounded-xl border border-orange-900/40 flex flex-col items-center shadow-inner">
            <span className="text-[9px] text-orange-700 font-black tracking-widest">СТАВКА</span>
            <div className="flex items-center justify-between w-full px-2">
               <button onClick={() => setBet(Math.max(10, bet-10))} disabled={isPlaying} className="text-orange-500 font-black text-xl hover:scale-110 active:scale-90">-</button>
               <div className="flex items-center">
                 <input 
                  type="number"
                  value={bet}
                  onChange={handleBetChange}
                  onBlur={handleBetBlur}
                  disabled={isPlaying}
                  className="bg-transparent text-sm font-black text-white text-center w-16 outline-none border-b border-orange-900/20 focus:border-orange-500"
                 />
                 <span className="text-[10px] font-black text-white ml-1">RUB</span>
               </div>
               <button onClick={() => setBet(Math.min(balance, bet+10))} disabled={isPlaying} className="text-orange-500 font-black text-xl hover:scale-110 active:scale-90">+</button>
            </div>
          </div>

          {!isPlaying ? (
            <button 
                onClick={startGame} 
                className="flex-[1.3] h-16 bg-gradient-to-b from-[#f93c1e] to-[#a31a0a] rounded-xl text-sm font-black text-white shadow-xl shadow-red-900/20 border-b-[4px] border-[#6a1107] active:border-b-0 active:translate-y-1 transition-all"
            >
                СДЕЛАТЬ СТАВКУ
            </button>
          ) : (
            <button 
                onClick={takeWin} 
                disabled={currentRow <= 0} 
                className="flex-[1.3] h-16 bg-gradient-to-b from-green-500 to-green-800 rounded-xl text-xs font-black text-white shadow-xl shadow-green-900/20 border-b-[4px] border-green-950 disabled:opacity-50 disabled:grayscale active:border-b-0 active:translate-y-1 transition-all flex flex-col items-center justify-center"
            >
              <span className="text-[9px] opacity-80 uppercase mb-0.5">ЗАБРАТЬ</span>
              <span className="text-sm">{(bet * (currentRow > 0 ? MULTIPLIERS[MULTIPLIERS.length - currentRow] : 1)).toFixed(0)} RUB</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default AppleOfFortune;
