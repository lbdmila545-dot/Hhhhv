
import React, { useState } from 'react';

interface BaccaratProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Baccarat: React.FC<BaccaratProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isDealing, setIsDealing] = useState(false);
  const [choice, setChoice] = useState<'PLAYER' | 'BANKER' | 'TIE'>('PLAYER');
  const [result, setResult] = useState<string>('');

  const play = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsDealing(true);
    setResult('');

    setTimeout(() => {
      const pScore = Math.floor(Math.random() * 10);
      const bScore = Math.floor(Math.random() * 10);
      
      let winner: 'PLAYER' | 'BANKER' | 'TIE';
      if (pScore > bScore) winner = 'PLAYER';
      else if (bScore > pScore) winner = 'BANKER';
      else winner = 'TIE';

      if (choice === winner) {
        const mult = winner === 'TIE' ? 8 : winner === 'BANKER' ? 1.95 : 2;
        onBalanceChange(Math.floor(bet * mult));
        setResult('ПОБЕДА!');
      } else {
        setResult('ПРОИГРЫШ');
      }
      setIsDealing(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#051a10] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-purple-500 uppercase">BACCARAT</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-10">
         <div className="flex gap-8 text-center">
            <div className="bg-blue-900/40 p-6 rounded-2xl border border-blue-500/30">
               <div className="text-[10px] font-black uppercase text-slate-500 mb-2">PLAYER</div>
               <div className="text-4xl font-black text-blue-400">?</div>
            </div>
            <div className="bg-red-900/40 p-6 rounded-2xl border border-red-500/30">
               <div className="text-[10px] font-black uppercase text-slate-500 mb-2">BANKER</div>
               <div className="text-4xl font-black text-red-400">?</div>
            </div>
         </div>

         <div className="text-3xl font-black uppercase italic text-yellow-500">{result}</div>

         <div className="grid grid-cols-3 gap-3 w-full">
            <button onClick={() => setChoice('PLAYER')} className={`py-4 rounded-xl border-2 transition-all font-black ${choice === 'PLAYER' ? 'bg-blue-600 border-white' : 'bg-slate-800 border-slate-700 opacity-60'}`}>PLAYER</button>
            <button onClick={() => setChoice('TIE')} className={`py-4 rounded-xl border-2 transition-all font-black ${choice === 'TIE' ? 'bg-green-600 border-white' : 'bg-slate-800 border-slate-700 opacity-60'}`}>TIE (x8)</button>
            <button onClick={() => setChoice('BANKER')} className={`py-4 rounded-xl border-2 transition-all font-black ${choice === 'BANKER' ? 'bg-red-600 border-white' : 'bg-slate-800 border-slate-700 opacity-60'}`}>BANKER</button>
         </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4">
        <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value))} className="w-full bg-black/40 p-4 rounded-2xl border border-slate-800 text-center font-black outline-none" />
        <button onClick={play} disabled={isDealing} className="w-full h-16 bg-purple-600 rounded-2xl font-black uppercase active:scale-95 disabled:opacity-50">СТАВКА</button>
      </div>
    </div>
  );
};

export default Baccarat;
