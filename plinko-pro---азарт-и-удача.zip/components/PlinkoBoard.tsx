
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { 
  CANVAS_WIDTH, CANVAS_HEIGHT, ROWS, PIN_SPACING_X, PIN_SPACING_Y, 
  BALL_RADIUS, PIN_RADIUS, GRAVITY, FRICTION, BOUNCE, MULTIPLIERS 
} from '../constants.ts';
import { Ball, Pin } from '../types.ts';

interface PlinkoBoardProps {
  onWin: (multiplier: number, originalBet: number) => void;
  shouldDrop: () => boolean;
  currentBet: number;
}

const PlinkoBoard: React.FC<PlinkoBoardProps> = ({ onWin, shouldDrop, currentBet }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ballsRef = useRef<Ball[]>([]);
  const pinsRef = useRef<Pin[]>([]);
  const requestRef = useRef<number>();
  const lastBallId = useRef(0);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playHitSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(800 + Math.random() * 400, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.05);
    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  };

  useEffect(() => {
    const pins: Pin[] = [];
    for (let row = 0; row < ROWS; row++) {
      const rowY = 50 + row * PIN_SPACING_Y;
      const rowPinsCount = row + 3;
      const rowWidth = (rowPinsCount - 1) * PIN_SPACING_X;
      const startX = (CANVAS_WIDTH - rowWidth) / 2;
      for (let col = 0; col < rowPinsCount; col++) {
        pins.push({ x: startX + col * PIN_SPACING_X, y: rowY, radius: PIN_RADIUS });
      }
    }
    pinsRef.current = pins;
  }, []);

  const handleCanvasClick = () => {
    initAudio();
    if (shouldDrop()) {
      const newBall: Ball = {
        id: lastBallId.current++,
        x: CANVAS_WIDTH / 2 + (Math.random() - 0.5) * 4,
        y: 20,
        vx: (Math.random() - 0.5) * 2,
        vy: 1,
        radius: BALL_RADIUS,
        betValue: currentBet,
        color: '#ff4444'
      };
      ballsRef.current.push(newBall);
    }
  };

  const update = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Отрисовка пинов
    ctx.fillStyle = '#475569';
    pinsRef.current.forEach(pin => {
      ctx.beginPath();
      ctx.arc(pin.x, pin.y, pin.radius, 0, Math.PI * 2);
      ctx.fill();
    });

    // Отрисовка множителей
    const multWidth = CANVAS_WIDTH / MULTIPLIERS.length;
    const bottomY = 50 + (ROWS) * PIN_SPACING_Y + 10;
    
    MULTIPLIERS.forEach((m, i) => {
      const x = i * multWidth;
      ctx.fillStyle = m.color;
      ctx.beginPath();
      ctx.roundRect(x + 2, bottomY, multWidth - 4, 30, 6);
      ctx.fill();
      ctx.fillStyle = 'white';
      ctx.font = 'bold 10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(m.label, x + multWidth / 2, bottomY + 20);
    });

    // Обновление шариков
    for (let i = ballsRef.current.length - 1; i >= 0; i--) {
      const ball = ballsRef.current[i];
      ball.vy += GRAVITY;
      ball.vx *= FRICTION;
      ball.vy *= FRICTION;
      ball.x += ball.vx;
      ball.y += ball.vy;

      // Коллизии со стенками
      if (ball.x < ball.radius || ball.x > CANVAS_WIDTH - ball.radius) {
        ball.vx *= -BOUNCE;
        ball.x = ball.x < ball.radius ? ball.radius : CANVAS_WIDTH - ball.radius;
      }

      // Коллизии с пинами
      pinsRef.current.forEach(pin => {
        const dx = ball.x - pin.x;
        const dy = ball.y - pin.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < ball.radius + pin.radius) {
          const angle = Math.atan2(dy, dx);
          const speed = Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy);
          ball.vx = Math.cos(angle) * speed * BOUNCE + (Math.random() - 0.5) * 0.5;
          ball.vy = Math.sin(angle) * speed * BOUNCE + 0.2;
          playHitSound();
        }
      });

      // Отрисовка шарика
      ctx.fillStyle = '#fbbf24';
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
      ctx.fill();

      // Попадание в лунку
      if (ball.y > bottomY) {
        const pocketIdx = Math.floor(ball.x / multWidth);
        const mult = MULTIPLIERS[Math.min(pocketIdx, MULTIPLIERS.length - 1)].value;
        onWin(mult, ball.betValue);
        ballsRef.current.splice(i, 1);
      }
    }
    requestRef.current = requestAnimationFrame(update);
  }, [onWin]);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(update);
    return () => { if (requestRef.current) cancelAnimationFrame(requestRef.current); };
  }, [update]);

  return (
    <div className="w-full h-full flex items-center justify-center cursor-pointer" onClick={handleCanvasClick}>
      <canvas 
        ref={canvasRef} 
        width={CANVAS_WIDTH} 
        height={CANVAS_HEIGHT} 
        className="max-h-full max-w-full object-contain" 
      />
    </div>
  );
};

export default PlinkoBoard;
