
import React, { useState } from 'react';

interface CryptProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Crypt: React.FC<CryptProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  const [status, setStatus] = useState<string>('');
  const [revealed, setRevealed] = useState<number | null>(null);
  const [winner, setWinner] = useState<number | null>(null);

  const start = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setStatus('ВЫБЕРИТЕ САРКОФАГ');
    setRevealed(null);
    setWinner(null);
  };

  const choose = (idx: number) => {
    if (!isPlaying || revealed !== null) return;
    const winIdx = Math.floor(Math.random() * 3);
    setWinner(winIdx);
    setRevealed(idx);
    
    if (idx === winIdx) {
      const win = bet * 2.8;
      onBalanceChange(Math.floor(win));
      setStatus('ЗОЛОТО НАЙДЕНО!');
    } else {
      setStatus('ПУСТО...');
    }
    setIsPlaying(false);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0500] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-emerald-500 uppercase">CRYPT</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-12">
         <div className="text-xl font-black uppercase tracking-widest text-emerald-400">{status}</div>
         <div className="flex gap-4">
            {[0,1,2].map(i => (
               <button 
                key={i} 
                onClick={() => choose(i)}
                className={`w-24 h-40 rounded-t-full border-4 transition-all duration-500 ${
                    revealed === i ? (winner === i ? 'bg-yellow-600 border-yellow-400' : 'bg-red-900 border-red-700 opacity-40') : 
                    'bg-slate-800 border-slate-700'
                }`}
               >
                  <i className={`fas ${revealed === i ? (winner === i ? 'fa-gem animate-bounce' : 'fa-skull-crossbones') : 'fa-door-closed'} text-2xl`}></i>
               </button>
            ))}
         </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4 shadow-2xl">
        <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value))} className="w-full bg-black/40 p-4 rounded-2xl border border-slate-800 text-center font-black" />
        <button onClick={start} disabled={isPlaying} className="w-full h-16 bg-emerald-700 rounded-2xl font-black uppercase">ИГРАТЬ</button>
      </div>
    </div>
  );
};

export default Crypt;
