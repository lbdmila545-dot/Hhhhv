
import React, { useState } from 'react';

interface ThimblesProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Thimbles: React.FC<ThimblesProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isMixing, setIsMixing] = useState(false);
  const [selected, setSelected] = useState<number | null>(null);
  const [ballPos, setBallPos] = useState<number | null>(null);

  const startMixing = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsMixing(true);
    setSelected(null);
    setBallPos(null);

    setTimeout(() => {
      setIsMixing(false);
    }, 1500);
  };

  const guess = (idx: number) => {
    if (isMixing || selected !== null) return;
    const finalPos = Math.floor(Math.random() * 3);
    setBallPos(finalPos);
    setSelected(idx);

    if (idx === finalPos) {
      onBalanceChange(Math.floor(bet * 2.88));
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#1a0f02] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-amber-500">THIMBLES</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="flex gap-4 mb-20">
          {[0, 1, 2].map(i => (
            <div key={i} onClick={() => guess(i)} className="relative group cursor-pointer">
              <div className={`w-24 h-28 bg-amber-800 rounded-t-full border-b-8 border-amber-950 transition-all duration-500 ${
                isMixing ? 'animate-bounce' : ''
              } ${selected !== null && i === selected ? '-translate-y-12' : ''}`}>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-amber-400 opacity-20"><i className="fas fa-cup-trowel text-4xl"></i></div>
              </div>
              {ballPos === i && (
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-8 h-8 bg-white rounded-full shadow-[0_0_15px_white]"></div>
              )}
            </div>
          ))}
        </div>

        {selected !== null && (
          <div className={`text-2xl font-black uppercase italic ${selected === ballPos ? 'text-green-400' : 'text-red-500'}`}>
            {selected === ballPos ? 'ВЫИГРЫШ!' : 'ПРОИГРЫШ'}
          </div>
        )}
      </div>

      <div className="bg-slate-900 p-6 rounded-t-[40px] space-y-4 shadow-2xl">
        <div className="flex justify-between items-center bg-black/40 p-4 rounded-2xl">
          <button onClick={() => setBet(Math.max(10, bet-10))} disabled={isMixing} className="text-amber-500 text-2xl font-black">-</button>
          <span className="font-black">{bet} RUB</span>
          <button onClick={() => setBet(bet+10)} disabled={isMixing} className="text-amber-500 text-2xl font-black">+</button>
        </div>
        <button 
          onClick={startMixing} 
          disabled={isMixing || balance < bet}
          className="w-full h-16 bg-amber-600 text-white font-black uppercase rounded-2xl shadow-xl active:scale-95 disabled:opacity-50"
        >
          ИГРАТЬ
        </button>
      </div>
    </div>
  );
};

export default Thimbles;
