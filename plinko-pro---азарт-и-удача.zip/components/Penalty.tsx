
import React, { useState } from 'react';

interface PenaltyProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Penalty: React.FC<PenaltyProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isShooting, setIsShooting] = useState(false);
  const [result, setResult] = useState<'GOAL' | 'SAVED' | null>(null);
  const [keeperPos, setKeeperPos] = useState<number | null>(null);

  const shoot = (target: number) => {
    if (isShooting || balance < bet) return;
    onBalanceChange(-bet);
    setIsShooting(true);
    setResult(null);

    setTimeout(() => {
      const kPos = Math.floor(Math.random() * 5);
      setKeeperPos(kPos);
      setIsShooting(false);
      
      if (target === kPos) {
        setResult('SAVED');
      } else {
        setResult('GOAL');
        onBalanceChange(Math.floor(bet * 4.85));
      }
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0d2a10] text-white">
      <div className="flex justify-between items-center p-4 bg-black/40 border-b border-green-500/20">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-green-400">PENALTY SHOOTOUT</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4">
        {/* Goal Area */}
        <div className="relative w-full max-w-sm h-64 bg-slate-900/50 rounded-t-3xl border-x-8 border-t-8 border-white/80 shadow-2xl flex items-center justify-center">
            {/* Net pattern */}
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_#fff_1px,_transparent_1px)] bg-[size:10px_10px]"></div>
            
            {/* Keeper */}
            <div className={`absolute bottom-4 transition-all duration-500 text-4xl ${
              keeperPos === 0 ? 'left-4' : keeperPos === 1 ? 'left-1/4' : keeperPos === 2 ? 'left-1/2 -translate-x-1/2' : keeperPos === 3 ? 'right-1/4' : 'right-4'
            }`}>
              <i className="fas fa-user-tie text-blue-500 drop-shadow-lg"></i>
            </div>

            {/* Shoot Targets */}
            <div className="absolute bottom-10 left-0 w-full flex justify-around px-4">
               {[0, 1, 2, 3, 4].map(i => (
                 <button key={i} onClick={() => shoot(i)} disabled={isShooting} className="w-12 h-12 rounded-full border-4 border-white/20 hover:border-green-400 transition-colors flex items-center justify-center">
                    <i className="fas fa-crosshairs opacity-30"></i>
                 </button>
               ))}
            </div>
        </div>

        <div className="mt-20 h-20 flex flex-col items-center justify-center">
           {result && (
             <div className={`text-4xl font-black italic tracking-widest ${result === 'GOAL' ? 'text-green-400 animate-bounce' : 'text-red-500'}`}>
                {result === 'GOAL' ? 'ГООООЛ!' : 'СЕЙВ!'}
             </div>
           )}
        </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4">
        <div className="flex justify-between items-center bg-black/40 p-4 rounded-2xl">
           <button onClick={() => setBet(Math.max(10, bet-10))} disabled={isShooting} className="text-green-500 text-2xl font-black">-</button>
           <span className="font-black">{bet} RUB</span>
           <button onClick={() => setBet(bet+10)} disabled={isShooting} className="text-green-500 text-2xl font-black">+</button>
        </div>
        <div className="text-[10px] text-slate-500 text-center font-black uppercase tracking-widest">ВЫБЕРИТЕ УГОЛ УДАРА</div>
      </div>
    </div>
  );
};

export default Penalty;
