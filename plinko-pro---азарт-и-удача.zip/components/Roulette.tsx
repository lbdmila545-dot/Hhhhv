
import React, { useState, useRef, useEffect } from 'react';

interface RouletteProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const ROULETTE_NUMBERS = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26];
const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

const Roulette: React.FC<RouletteProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState<number | null>(null);
  const [selection, setSelection] = useState<'RED' | 'BLACK' | 'ZERO'>('RED');
  
  const rotationRef = useRef(0);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
  };

  const playTick = () => {
    if (!audioCtxRef.current) return;
    const osc = audioCtxRef.current.createOscillator();
    const gain = audioCtxRef.current.createGain();
    osc.frequency.setValueAtTime(1000, audioCtxRef.current.currentTime);
    gain.gain.setValueAtTime(0.05, audioCtxRef.current.currentTime);
    osc.connect(gain);
    gain.connect(audioCtxRef.current.destination);
    osc.start();
    osc.stop(audioCtxRef.current.currentTime + 0.02);
  };

  const spin = () => {
    if (balance < bet || isSpinning) return;
    initAudio();
    onBalanceChange(-bet);
    setIsSpinning(true);
    setResult(null);

    const targetRotation = rotationRef.current + (360 * 5) + Math.random() * 360;
    const duration = 4000;
    const start = performance.now();

    const animate = (time: number) => {
      const elapsed = time - start;
      const progress = Math.min(elapsed / duration, 1);
      const easeOut = 1 - Math.pow(1 - progress, 4);
      const currentRotation = rotationRef.current + (targetRotation - rotationRef.current) * easeOut;
      
      setRotation(currentRotation);
      if (Math.floor(currentRotation / 10) !== Math.floor(rotationRef.current / 10)) playTick();
      
      if (progress < 1) requestAnimationFrame(animate);
      else {
        rotationRef.current = currentRotation;
        const finalAngle = (currentRotation % 360 + 360) % 360;
        const winningNumber = ROULETTE_NUMBERS[Math.floor(((360 - finalAngle) % 360) / (360/37)) % 37];
        setResult(winningNumber);
        setIsSpinning(false);

        const isRed = RED_NUMBERS.includes(winningNumber);
        const won = (selection === 'RED' && isRed) || (selection === 'BLACK' && winningNumber !== 0 && !isRed) || (selection === 'ZERO' && winningNumber === 0);
        if (won) onBalanceChange(selection === 'ZERO' ? bet * 36 : bet * 2);
      }
    };
    requestAnimationFrame(animate);
  };

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 overflow-hidden">
      <div className="p-3 flex items-center justify-between flex-shrink-0">
        <button onClick={onBack} className="text-xs font-bold text-slate-400"><i className="fas fa-chevron-left mr-1"></i> Назад</button>
        <div className="text-center"><span className="text-[10px] font-black uppercase text-green-500">PRO ROULETTE</span></div>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 min-h-0 flex flex-col items-center justify-center p-4 relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[110px] z-30 w-4 h-6 bg-white clip-pointer"></div>
        <div className="relative w-[220px] h-[220px] sm:w-[280px] sm:h-[280px] flex items-center justify-center transition-all">
            <div className="absolute inset-0 rounded-full border-8 border-yellow-700 shadow-2xl z-20"></div>
            <div className="w-full h-full rounded-full overflow-hidden relative z-10" style={{ transform: `rotate(${rotation}deg)` }}>
                {ROULETTE_NUMBERS.map((num, i) => {
                    const angle = (i * 360) / 37;
                    const isRed = RED_NUMBERS.includes(num);
                    return (
                        <div key={i} className="absolute top-0 left-1/2 -translate-x-1/2 w-[16px] h-1/2 origin-bottom flex flex-col items-center pt-1" style={{ transform: `rotate(${angle}deg)`, backgroundColor: num === 0 ? '#10b981' : isRed ? '#ef4444' : '#18181b', clipPath: 'polygon(0% 0%, 100% 0%, 80% 100%, 20% 100%)' }}>
                            <span className="text-[8px] font-bold transform rotate-180" style={{ writingMode: 'vertical-rl' }}>{num}</span>
                        </div>
                    );
                })}
            </div>
            <div className="absolute inset-0 m-auto w-16 h-16 bg-slate-900 rounded-full border-2 border-yellow-600 z-20 flex items-center justify-center">
                <span className="text-xl font-black">{result !== null ? result : '?'}</span>
            </div>
        </div>
      </div>

      <div className="p-4 bg-slate-900/80 rounded-t-3xl border-t border-slate-800 flex-shrink-0">
        <div className="grid grid-cols-3 gap-2 mb-4">
           {['RED', 'ZERO', 'BLACK'].map(type => (
             <button key={type} onClick={() => setSelection(type as any)} disabled={isSpinning} className={`py-3 rounded-xl text-[10px] font-black border-2 transition-all ${selection === type ? 'border-white scale-105' : 'border-transparent opacity-50'} ${type === 'RED' ? 'bg-red-600' : type === 'BLACK' ? 'bg-zinc-950' : 'bg-green-600'}`}>{type}</button>
           ))}
        </div>
        <div className="flex gap-2 mb-4">
            <input type="number" value={bet} onChange={e => setBet(Math.max(1, parseInt(e.target.value) || 0))} className="flex-1 bg-black rounded-xl p-3 text-sm font-black text-center outline-none border border-slate-700" />
            <button onClick={() => setBet(Math.min(balance, bet*2))} className="bg-slate-800 px-4 rounded-xl font-bold text-xs">x2</button>
        </div>
        <button onClick={spin} disabled={isSpinning || balance < bet} className="w-full py-4 bg-green-600 rounded-xl font-black uppercase text-sm active:scale-95 transition-all shadow-lg shadow-green-900/20">{isSpinning ? 'Крутим...' : 'Сделать ставку'}</button>
      </div>
      <style>{`.clip-pointer { clip-path: polygon(0% 0%, 100% 0%, 50% 100%); }`}</style>
    </div>
  );
};

export default Roulette;
