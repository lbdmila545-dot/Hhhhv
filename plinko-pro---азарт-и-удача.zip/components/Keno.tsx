
import React, { useState } from 'react';

interface KenoProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Keno: React.FC<KenoProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [selected, setSelected] = useState<number[]>([]);
  const [drawn, setDrawn] = useState<number[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const toggleNumber = (num: number) => {
    if (isDrawing) return;
    if (selected.includes(num)) {
      setSelected(selected.filter(n => n !== num));
    } else if (selected.length < 10) {
      setSelected([...selected, num]);
    }
  };

  const startDraw = () => {
    if (balance < bet || selected.length === 0) return;
    onBalanceChange(-bet);
    setIsDrawing(true);
    setDrawn([]);
    setMessage(null);

    let count = 0;
    const interval = setInterval(() => {
      let next;
      do { next = Math.floor(Math.random() * 80) + 1; } while (drawn.includes(next));
      setDrawn(prev => [...prev, next]);
      count++;
      if (count === 20) {
        clearInterval(interval);
        checkWin([...drawn, next]);
        setIsDrawing(false);
      }
    }, 100);
  };

  const checkWin = (finalDrawn: number[]) => {
    const hits = selected.filter(n => finalDrawn.includes(n)).length;
    if (hits > 0) {
      const mults = [0, 1.5, 3, 10, 50, 200, 500, 1000, 2000, 5000, 10000];
      const win = Math.floor(bet * mults[hits]);
      onBalanceChange(win);
      setMessage(`ПОПАДАНИЙ: ${hits}! ВЫИГРЫШ: +${win} RUB`);
    } else {
      setMessage('НЕТ ПОПАДАНИЙ');
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#051a1a] text-white">
      <div className="flex justify-between items-center p-4 bg-black/40 border-b border-cyan-500/20">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-cyan-400">KENO LOTTERY</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 no-scrollbar">
        <div className="grid grid-cols-8 gap-1 mb-6">
          {Array(80).fill(0).map((_, i) => {
            const num = i + 1;
            const isSelected = selected.includes(num);
            const isHit = drawn.includes(num) && isSelected;
            const isDrawn = drawn.includes(num);
            return (
              <button 
                key={num} 
                onClick={() => toggleNumber(num)}
                className={`aspect-square text-[9px] font-black rounded border transition-all ${
                  isHit ? 'bg-green-500 border-green-400 animate-pulse' :
                  isDrawn ? 'bg-cyan-600 border-cyan-400 scale-90' :
                  isSelected ? 'bg-blue-600 border-blue-400' : 'bg-slate-800 border-slate-700/50 opacity-60'
                }`}
              >
                {num}
              </button>
            );
          })}
        </div>
        
        {message && <div className="text-center py-4 bg-cyan-900/20 border border-cyan-500/30 rounded-2xl text-cyan-400 font-black uppercase text-xs">{message}</div>}
      </div>

      <div className="p-6 bg-slate-900 rounded-t-[40px] space-y-4">
        <div className="flex justify-between items-center text-[10px] font-black uppercase text-slate-500 tracking-widest px-2">
            <span>Выбрано: {selected.length}/10</span>
            <span>Ставка: {bet} RUB</span>
        </div>
        <button 
          onClick={startDraw} 
          disabled={isDrawing || selected.length === 0 || balance < bet}
          className="w-full h-16 bg-cyan-600 text-white font-black uppercase rounded-2xl shadow-xl shadow-cyan-900/40 active:scale-95 disabled:opacity-50"
        >
          {isDrawing ? 'РОЗЫГРЫШ...' : 'ИГРАТЬ'}
        </button>
      </div>
    </div>
  );
};

export default Keno;
