
import React, { useEffect, useState, useRef } from 'react';
import { UserProfile } from '../types.ts';

interface HeaderProps {
  balance: number;
  user: UserProfile | null;
  onHome: () => void;
  onProfile: () => void;
  isOnline: boolean;
}

const Header: React.FC<HeaderProps> = ({ balance, user, onHome, onProfile, isOnline }) => {
  const xpProgress = user ? (user.xp / (user.level * 500)) * 100 : 0;
  const [pulse, setPulse] = useState(false);
  const prevBalance = useRef(balance);

  useEffect(() => {
    if (balance !== prevBalance.current) {
      setPulse(true);
      const timer = setTimeout(() => setPulse(false), 500);
      prevBalance.current = balance;
      return () => clearTimeout(timer);
    }
  }, [balance]);

  return (
    <div className="p-4 flex flex-col gap-3 bg-[#1e293b] rounded-b-3xl shadow-xl z-50">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 cursor-pointer active:scale-95 transition-transform" onClick={onHome}>
                <span className="text-2xl font-black italic text-blue-500 tracking-tighter">1XBET</span>
            </div>
            <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full border text-[8px] font-black uppercase tracking-widest ${
                isOnline ? 'bg-green-600/10 border-green-500/50 text-green-400' : 'bg-red-600/10 border-red-500/50 text-red-400 animate-pulse'
            }`}>
                <div className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
                {isOnline ? 'Online' : 'Offline'}
            </div>
        </div>
        <div className="flex items-center gap-3">
          {user && (
            <div className="flex flex-col items-end">
                <div className="flex items-center gap-2 bg-slate-800 py-1 px-3 rounded-full border border-slate-700 cursor-pointer hover:bg-slate-700 transition-colors" onClick={onProfile}>
                    <span className="text-[10px] font-black text-blue-400 uppercase">LVL {user.level}</span>
                    <i className="fas fa-user-circle text-slate-300"></i>
                </div>
                <div className="w-20 h-1.5 bg-slate-900 rounded-full mt-1.5 overflow-hidden">
                    <div 
                        className="h-full bg-blue-500 transition-all duration-700 ease-out shadow-[0_0_8px_rgba(59,130,246,0.8)]" 
                        style={{ width: `${Math.min(100, xpProgress)}%` }}
                    ></div>
                </div>
            </div>
          )}
        </div>
      </div>

      <div className={`bg-[#0f172a] p-3 rounded-2xl border transition-all duration-300 flex justify-between items-center shadow-inner ${pulse ? 'border-blue-500 ring-2 ring-blue-500/20 scale-[1.02]' : 'border-slate-700'}`}>
         <div className="flex flex-col">
            <span className="text-[9px] text-slate-500 uppercase font-black tracking-widest mb-0.5">Баланс счета</span>
            <span className={`font-mono font-black text-xl leading-none transition-colors duration-300 ${pulse ? 'text-white' : 'text-blue-400'}`}>
                {balance.toLocaleString()} <span className="text-xs">RUB</span>
            </span>
         </div>
         <button onClick={onProfile} className="w-10 h-10 bg-blue-600 rounded-xl shadow-lg flex items-center justify-center active:scale-90 transition-transform hover:bg-blue-500">
            <i className="fas fa-plus text-white text-sm"></i>
         </button>
      </div>
    </div>
  );
};

export default Header;