
import React, { useState } from 'react';

interface PlumberProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Plumber: React.FC<PlumberProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [status, setStatus] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState(false);

  const start = (path: number) => {
    if (balance < bet || isPlaying) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setStatus('ВОДА ТЕЧЕТ...');

    setTimeout(() => {
      const blocked = Math.floor(Math.random() * 3);
      if (path !== blocked) {
        onBalanceChange(bet * 2.5);
        setStatus('УСПЕХ! x2.5');
      } else {
        setStatus('ПРОТЕЧКА!');
      }
      setIsPlaying(false);
    }, 1200);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a1a1f] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-cyan-500 uppercase">PLUMBER</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-12">
         <div className="text-3xl font-black uppercase italic text-cyan-400">{status}</div>
         <div className="flex gap-6">
            {[0,1,2].map(i => (
               <button 
                key={i} 
                onClick={() => start(i)}
                disabled={isPlaying}
                className="w-20 h-32 bg-slate-800 rounded-b-3xl border-x-4 border-b-4 border-slate-600 flex flex-col items-center pt-4 transition-all hover:bg-cyan-900/40 active:scale-90"
               >
                  <i className="fas fa-faucet text-3xl mb-4"></i>
                  <span className="text-[10px] font-black uppercase">ТРУБА {i+1}</span>
               </button>
            ))}
         </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4">
        <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value))} className="w-full bg-black/40 p-4 rounded-2xl border border-slate-800 text-center font-black outline-none" />
        <div className="text-[10px] text-center text-slate-500 font-black">ВЫБЕРИТЕ ИСПРАВНУЮ ТРУБУ</div>
      </div>
    </div>
  );
};

export default Plumber;
