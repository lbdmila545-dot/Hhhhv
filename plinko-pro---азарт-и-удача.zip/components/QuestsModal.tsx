
import React from 'react';
import { Quest } from '../types.ts';

interface QuestsModalProps {
  quests: Quest[];
  onClaim: (id: string, reward: number) => void;
  onClose: () => void;
}

const QuestsModal: React.FC<QuestsModalProps> = ({ quests, onClaim, onClose }) => {
  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex flex-col animate-in zoom-in duration-300">
      <div className="p-4 flex justify-between items-center border-b border-slate-800">
        <h2 className="text-xl font-black uppercase italic tracking-tighter">Ежедневные задания</h2>
        <button onClick={onClose} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-times"></i></button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
        {quests.map(q => (
          <div key={q.id} className="bg-slate-900 p-6 rounded-3xl border border-slate-800 space-y-4">
             <div className="flex justify-between items-start">
                <div className="flex flex-col">
                   <h3 className="text-sm font-black uppercase">{q.title}</h3>
                   <span className="text-xs text-slate-500 font-bold">Награда: <span className="text-green-500">{q.reward} RUB</span></span>
                </div>
                <div className="text-[10px] font-black text-blue-400">{q.current} / {q.target}</div>
             </div>
             
             <div className="w-full h-2 bg-black rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-600" 
                  style={{ width: `${(q.current / q.target) * 100}%` }}
                ></div>
             </div>

             <button 
                disabled={q.current < q.target || q.isClaimed}
                onClick={() => onClaim(q.id, q.reward)}
                className={`w-full py-3 rounded-xl font-black uppercase text-xs transition-all ${
                  q.isClaimed ? 'bg-slate-800 text-slate-500' :
                  q.current >= q.target ? 'bg-green-600 shadow-lg shadow-green-900/40' : 'bg-slate-700 opacity-50'
                }`}
             >
                {q.isClaimed ? 'Забрано' : 'Забрать бонус'}
             </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default QuestsModal;
