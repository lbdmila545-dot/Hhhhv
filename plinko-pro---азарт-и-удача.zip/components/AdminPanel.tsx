
import React, { useState } from 'react';
import { CustomPromo } from '../types.ts';

interface AdminPanelProps {
  promos: CustomPromo[];
  onClose: () => void;
  onUpdateBalance: (amount: number) => void;
  onAddPromo: (promo: CustomPromo) => void;
  onDeletePromo: (code: string) => void;
  onReset: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ promos, onClose, onUpdateBalance, onAddPromo, onDeletePromo, onReset }) => {
  const [newCode, setNewCode] = useState('');
  const [newReward, setNewReward] = useState('5000');
  const [balanceAdd, setBalanceAdd] = useState('100000');

  const handleCreate = () => {
    if (!newCode) return;
    onAddPromo({ code: newCode.toUpperCase(), reward: parseInt(newReward), uses: 0 });
    setNewCode('');
  };

  return (
    <div className="fixed inset-0 z-[300] bg-[#020617] p-6 overflow-y-auto flex flex-col items-center animate-in fade-in duration-300">
      <div className="w-full max-w-lg relative z-10">
          <div className="flex justify-between items-center mb-8">
            <div className="flex flex-col">
                <h1 className="text-2xl font-black italic text-red-500 leading-none">ADMIN DASHBOARD</h1>
                <span className="text-[10px] text-slate-500 font-bold uppercase mt-1">Система управления v5.0</span>
            </div>
            <button onClick={onClose} className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center border border-slate-700 shadow-lg active:scale-90">
              <i className="fas fa-times text-white"></i>
            </button>
          </div>

          <div className="space-y-8">
            {/* Баланс */}
            <section className="bg-[#0f172a] p-6 rounded-[32px] border border-slate-800 shadow-2xl">
               <h3 className="text-xs font-black uppercase text-slate-400 mb-4 tracking-widest">Управление балансом</h3>
               <div className="flex gap-2">
                  <input type="number" value={balanceAdd} onChange={e => setBalanceAdd(e.target.value)} className="flex-1 bg-black rounded-2xl px-5 py-4 outline-none border border-slate-700 focus:border-red-500 font-mono text-white" />
                  <button onClick={() => onUpdateBalance(parseInt(balanceAdd))} className="bg-red-600 px-6 py-4 rounded-2xl font-black text-xs uppercase shadow-lg shadow-red-900/20 active:scale-95 border-b-4 border-red-800">ДОБАВИТЬ</button>
               </div>
            </section>

            {/* Промокоды */}
            <section className="bg-[#0f172a] p-6 rounded-[32px] border border-slate-800 shadow-2xl">
               <h3 className="text-xs font-black uppercase text-slate-400 mb-4 tracking-widest">Создание промокодов</h3>
               <div className="space-y-3">
                  <input placeholder="Код (напр. PROMO777)" value={newCode} onChange={e => setNewCode(e.target.value)} className="w-full bg-black rounded-2xl px-5 py-4 outline-none border border-slate-700 focus:border-red-500 font-mono" />
                  <input type="number" placeholder="Сумма вознаграждения" value={newReward} onChange={e => setNewReward(e.target.value)} className="w-full bg-black rounded-2xl px-5 py-4 outline-none border border-slate-700 focus:border-red-500 font-mono" />
                  <button onClick={handleCreate} className="w-full bg-blue-600 py-5 rounded-2xl font-black text-xs uppercase shadow-xl shadow-blue-900/40 border-b-4 border-blue-800 active:scale-95">Создать промокод</button>
               </div>

               {promos.length > 0 && (
                 <div className="mt-8 space-y-3">
                    <div className="text-[10px] font-black text-slate-500 uppercase mb-2">Активные коды ({promos.length})</div>
                    {promos.map(p => (
                      <div key={p.code} className="bg-black/60 p-4 rounded-2xl border border-slate-800 flex justify-between items-center shadow-inner">
                        <span className="font-mono text-blue-400 font-bold">{p.code}</span>
                        <div className="flex items-center gap-4">
                           <span className="text-xs font-black text-white">{p.reward.toLocaleString()} RUB</span>
                           <button onClick={() => onDeletePromo(p.code)} className="text-red-500 w-8 h-8 flex items-center justify-center hover:bg-red-500/10 rounded-full transition-colors"><i className="fas fa-trash"></i></button>
                        </div>
                      </div>
                    ))}
                 </div>
               )}
            </section>

            <section className="bg-red-950/20 p-6 rounded-[32px] border border-red-900/50">
               <h3 className="text-xs font-black uppercase text-red-500 mb-4 tracking-widest">Опасная зона</h3>
               <button onClick={() => { if(confirm("Внимание! Это действие удалит весь прогресс, баланс и настройки. Продолжить?")) onReset(); }} className="w-full bg-red-600/10 text-red-500 border border-red-500/50 py-5 rounded-2xl font-black text-xs uppercase hover:bg-red-600 hover:text-white transition-all shadow-lg active:scale-95">Сбросить все данные</button>
            </section>
          </div>
      </div>
    </div>
  );
};

export default AdminPanel;