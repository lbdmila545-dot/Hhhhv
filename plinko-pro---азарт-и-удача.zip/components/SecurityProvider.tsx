
import React, { useEffect, useState, useRef } from 'react';
import { BanInfo } from '../types.ts';

interface SecurityProviderProps {
  onBan: (reason: string) => void;
  banInfo?: BanInfo;
  children: React.ReactNode;
}

const SecurityProvider: React.FC<SecurityProviderProps> = ({ onBan, banInfo, children }) => {
  const isBanningRef = useRef(false);

  useEffect(() => {
    // Honey-pot
    (window as any).game_balance = 999999;
    (window as any).user_credits = 500000;
    
    const checkHoneyPot = setInterval(() => {
      if (!isBanningRef.current && ((window as any).game_balance !== 999999 || (window as any).user_credits !== 500000)) {
        isBanningRef.current = true;
        onBan("Использование сторонних программ (Memory Edit / Game Guardian)");
      }
    }, 2000);

    // SpeedHack detector
    let lastTime = performance.now();
    let lastRealTime = Date.now();
    
    const checkSpeed = setInterval(() => {
        const currentTime = performance.now();
        const currentRealTime = Date.now();
        
        const deltaPerf = currentTime - lastTime;
        const deltaReal = currentRealTime - lastRealTime;
        
        if (!isBanningRef.current && deltaPerf > deltaReal * 2.5 && deltaReal > 500) {
            isBanningRef.current = true;
            onBan("Обнаружено ускорение времени (SpeedHack)");
        }
        
        lastTime = currentTime;
        lastRealTime = currentRealTime;
    }, 1000);

    // DevTools blocker
    const handleKey = (e: KeyboardEvent) => {
        if (e.keyCode === 123 || (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || (e.ctrlKey && e.keyCode === 85)) {
            e.preventDefault();
        }
    };
    
    document.addEventListener('keydown', handleKey);
    document.addEventListener('contextmenu', (e) => e.preventDefault());

    return () => {
      clearInterval(checkHoneyPot);
      clearInterval(checkSpeed);
      document.removeEventListener('keydown', handleKey);
    };
  }, [onBan]);

  if (banInfo?.isBanned) {
    const isPermanent = banInfo.expiresAt === 'PERMANENT';
    const timeLeft = !isPermanent ? (banInfo.expiresAt as number) - Date.now() : 0;
    
    return (
      <div className="fixed inset-0 z-[1000] bg-black flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-500">
        <div className="w-24 h-24 bg-red-600 rounded-full flex items-center justify-center mb-8 animate-pulse shadow-[0_0_50px_rgba(220,38,38,0.5)]">
            <i className="fas fa-user-slash text-4xl text-white"></i>
        </div>
        <h1 className="text-3xl font-black text-red-500 uppercase italic mb-4">Доступ заблокирован</h1>
        <div className="bg-slate-900 border border-red-500/30 p-6 rounded-3xl max-w-md w-full shadow-2xl">
            <p className="text-slate-300 text-sm mb-4">Ваш аккаунт и устройство были заблокированы системой безопасности <span className="text-red-500 font-bold">ANTI-CHEAT 1X</span>.</p>
            <div className="space-y-2 text-left bg-black/40 p-4 rounded-2xl mb-6">
                <div className="text-[10px] text-slate-500 uppercase font-black">Причина:</div>
                <div className="text-sm text-white font-bold">{banInfo.reason}</div>
                <div className="text-[10px] text-slate-500 uppercase font-black mt-2">Срок:</div>
                <div className="text-sm text-red-400 font-bold">
                    {isPermanent ? 'НАВСЕГДА (ПО ЖЕЛЕЗУ)' : `${Math.max(0, Math.ceil(timeLeft / (1000 * 60 * 60)))} часов`}
                </div>
                <div className="text-[10px] text-slate-500 uppercase font-black mt-2">Нарушение №:</div>
                <div className="text-sm text-white font-bold">{banInfo.violations} / 4</div>
            </div>
            <p className="text-[10px] text-slate-500 leading-relaxed italic">
                Все попытки обхода бана приведут к немедленной блокировке платежных реквизитов.
            </p>
        </div>
        <div className="mt-8 opacity-20 text-[10px] font-mono select-all">HWID-TOKEN: {banInfo.hwid}</div>
      </div>
    );
  }

  return <>{children}</>;
};

export default SecurityProvider;