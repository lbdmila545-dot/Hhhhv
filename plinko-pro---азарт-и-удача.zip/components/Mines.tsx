
import React, { useState, useCallback, useRef } from 'react';

interface MinesProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Mines: React.FC<MinesProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [mineCount, setMineCount] = useState(3);
  const [grid, setGrid] = useState<(null | 'star' | 'bomb')[]>(Array(25).fill(null));
  const [isPlaying, setIsPlaying] = useState(false);
  const [revealedCount, setRevealedCount] = useState(0);
  const [bombs, setBombs] = useState<number[]>([]);
  const [gameOver, setGameOver] = useState(false);
  const [isCashingOut, setIsCashingOut] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playSound = (type: 'reveal' | 'bomb' | 'win' | 'click') => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === 'reveal') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800 + (revealedCount * 50), ctx.currentTime);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
    } else if (type === 'bomb') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(100, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.4);
    } else if (type === 'win') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5);
    } else {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.05);
    }

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.5);
  };

  const calculateMultiplier = useCallback(() => {
    if (revealedCount === 0) return 0;
    let mult = 1.0;
    for (let i = 0; i < revealedCount; i++) {
      mult *= (25 - i) / (25 - i - mineCount);
    }
    return Math.min(1000, mult * 0.97);
  }, [revealedCount, mineCount]);

  const startGame = () => {
    initAudio();
    if (balance < bet) return;
    playSound('click');
    onBalanceChange(-bet);
    setIsPlaying(true);
    setGameOver(false);
    setIsCashingOut(false);
    setRevealedCount(0);
    setGrid(Array(25).fill(null));
    const newBombs: number[] = [];
    while (newBombs.length < mineCount) {
      const pos = Math.floor(Math.random() * 25);
      if (!newBombs.includes(pos)) newBombs.push(pos);
    }
    setBombs(newBombs);
  };

  const handleTileClick = (index: number) => {
    if (!isPlaying || grid[index] !== null || gameOver) return;
    initAudio();
    if (bombs.includes(index)) {
      playSound('bomb');
      setGameOver(true);
      setIsPlaying(false);
      const newGrid = [...grid];
      bombs.forEach(b => newGrid[b] = 'bomb');
      setGrid(newGrid);
    } else {
      playSound('reveal');
      const newGrid = [...grid];
      newGrid[index] = 'star';
      setGrid(newGrid);
      setRevealedCount(prev => prev + 1);
    }
  };

  const takeWin = () => {
    if (!isPlaying || revealedCount === 0 || gameOver) return;
    initAudio();
    playSound('win');
    const winAmount = Math.floor(bet * calculateMultiplier());
    onBalanceChange(winAmount);
    setIsPlaying(false);
    setGameOver(true);
    setIsCashingOut(true);
    const newGrid = [...grid];
    bombs.forEach(b => newGrid[b] = 'bomb');
    setGrid(newGrid);
  };

  const quickBet = (type: 'min' | 'half' | 'double' | 'max') => {
    if (isPlaying) return;
    initAudio();
    playSound('click');
    let n = bet;
    if (type === 'min') n = 10;
    if (type === 'half') n = Math.max(10, Math.floor(bet/2));
    if (type === 'double') n = Math.min(balance, bet*2);
    if (type === 'max') n = Math.floor(balance);
    setBet(n);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0a0f] text-white overflow-hidden">
      <div className="flex justify-between items-center p-3 bg-slate-900/50 border-b border-blue-500/20 flex-shrink-0">
        <button onClick={onBack} className="w-9 h-9 bg-slate-800 rounded-xl flex items-center justify-center active:scale-90">
            <i className="fas fa-arrow-left text-sm"></i>
        </button>
        <span className="font-black italic uppercase text-blue-500 tracking-tighter text-sm">MINES PRO</span>
        <div className="w-9"></div>
      </div>
      <div className="flex-1 p-2 flex flex-col items-center justify-center min-h-0 overflow-hidden">
        <div className="grid grid-cols-5 gap-1.5 w-full max-w-[280px]">
          {grid.map((tile, i) => (
            <button
              key={i}
              onClick={() => handleTileClick(i)}
              className={`aspect-square rounded-xl flex items-center justify-center text-2xl transition-all duration-300 ${
                tile === 'star' ? 'bg-blue-600 shadow-lg border border-blue-400' :
                tile === 'bomb' ? 'bg-red-600 shadow-lg border border-red-400' :
                'bg-slate-800/80 border border-slate-700/50 active:scale-90'
              }`}
            >
              {tile === 'star' && <i className="fas fa-star text-white drop-shadow-lg"></i>}
              {tile === 'bomb' && <i className="fas fa-bomb text-white animate-bounce"></i>}
            </button>
          ))}
        </div>
        <div className="mt-4 text-center h-12 flex flex-col items-center justify-center flex-shrink-0">
            {revealedCount > 0 && isPlaying && (
                <div className="animate-in zoom-in duration-300">
                    <div className="text-2xl font-black text-blue-400 italic">x{calculateMultiplier().toFixed(2)}</div>
                    <div className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">Коэффициент</div>
                </div>
            )}
            {gameOver && (
                <div className={`text-base font-black uppercase italic ${isCashingOut ? 'text-green-400' : 'text-red-500'}`}>
                    {isCashingOut ? `+${Math.floor(bet * calculateMultiplier())} RUB` : 'ВЗРЫВ!'}
                </div>
            )}
        </div>
      </div>
      <div className="p-4 bg-slate-900/95 space-y-3 rounded-t-3xl shadow-2xl flex-shrink-0">
        <div className="flex gap-2">
            <div className="flex-1 bg-black/40 p-2.5 rounded-xl border border-slate-700">
                <div className="text-[8px] text-slate-500 uppercase font-black mb-1 text-center">МИНЫ: {mineCount}</div>
                <input type="range" min="1" max="24" value={mineCount} onChange={e => setMineCount(parseInt(e.target.value))} disabled={isPlaying} className="w-full h-1 bg-slate-700 rounded-lg appearance-none accent-blue-500" />
            </div>
            <div className="flex-1 bg-black/40 p-2.5 rounded-xl border border-slate-700">
                <div className="text-[8px] text-slate-500 uppercase font-black mb-1 text-center">СТАВКА</div>
                <div className="flex items-center justify-center gap-2">
                    <button onClick={() => setBet(Math.max(10, bet-10))} disabled={isPlaying} className="text-blue-500 font-black text-lg">-</button>
                    <span className="text-sm font-black min-w-[40px] text-center">{bet}</span>
                    <button onClick={() => setBet(bet+10)} disabled={isPlaying} className="text-blue-500 font-black text-lg">+</button>
                </div>
            </div>
        </div>
        {!isPlaying ? (
            <button onClick={startGame} disabled={balance < bet} className={`w-full h-12 rounded-xl font-black uppercase text-xs transition-all ${balance < bet ? 'bg-slate-800 text-slate-600' : 'bg-blue-600 active:scale-95'}`}>
                ИГРАТЬ
            </button>
        ) : (
            <button onClick={takeWin} disabled={revealedCount === 0} className="w-full h-12 bg-green-600 rounded-xl font-black uppercase text-xs active:scale-95 flex flex-col items-center justify-center">
                <span className="text-[8px] opacity-80">ЗАБРАТЬ</span>
                <span>{Math.floor(bet * calculateMultiplier())} RUB</span>
            </button>
        )}
      </div>
    </div>
  );
};

export default Mines;
