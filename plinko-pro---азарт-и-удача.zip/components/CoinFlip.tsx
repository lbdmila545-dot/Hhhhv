
import React, { useState, useRef } from 'react';

interface CoinFlipProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const CoinFlip: React.FC<CoinFlipProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<'HEADS' | 'TAILS' | null>(null);
  const [choice, setChoice] = useState<'HEADS' | 'TAILS'>('HEADS');
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playSound = (type: 'flip' | 'win' | 'lose') => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === 'flip') {
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(1200, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
    } else if (type === 'win') {
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.5);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
    } else {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
    }

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  };

  const handleFlip = () => {
    if (isFlipping || balance < bet) return;
    initAudio();
    onBalanceChange(-bet);
    setIsFlipping(true);
    setResult(null);
    playSound('flip');

    setTimeout(() => {
        const outcome = Math.random() > 0.5 ? 'HEADS' : 'TAILS';
        setResult(outcome);
        setIsFlipping(false);
        if (outcome === choice) {
            playSound('win');
            onBalanceChange(bet * 2);
        } else {
            playSound('lose');
        }
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full bg-[#0f172a] p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center">
            <i className="fas fa-arrow-left"></i>
        </button>
        <span className="font-black italic uppercase text-yellow-500">COIN FLIP</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className={`relative w-40 h-40 transition-all duration-[1.5s] preserve-3d transform-gpu ${isFlipping ? 'animate-coin-spin' : ''}`}>
           <div className={`absolute inset-0 bg-yellow-500 rounded-full border-8 border-yellow-600 flex items-center justify-center shadow-2xl ${result === 'TAILS' ? 'rotate-y-180' : ''}`}>
             <span className="text-yellow-900 text-6xl font-black">{result === 'TAILS' ? 'T' : 'H'}</span>
           </div>
        </div>

        <div className="mt-20 flex gap-4 w-full">
            <button 
                onClick={() => setChoice('HEADS')}
                className={`flex-1 py-4 rounded-2xl font-black transition-all ${choice === 'HEADS' ? 'bg-yellow-500 text-yellow-900' : 'bg-slate-800 text-slate-500'}`}
            >ОРЕЛ</button>
            <button 
                onClick={() => setChoice('TAILS')}
                className={`flex-1 py-4 rounded-2xl font-black transition-all ${choice === 'TAILS' ? 'bg-yellow-500 text-yellow-900' : 'bg-slate-800 text-slate-500'}`}
            >РЕШКА</button>
        </div>

        {result && (
            <div className={`mt-8 text-2xl font-black uppercase italic ${result === choice ? 'text-green-400' : 'text-red-400'}`}>
                {result === choice ? 'ВЫИГРЫШ!' : 'ПРОИГРЫШ'}
            </div>
        )}
      </div>

      <div className="bg-slate-900 p-4 rounded-3xl border border-slate-700">
        <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
                <button onClick={() => setBet(Math.max(10, bet-10))} className="w-8 h-8 bg-slate-800 rounded-full">-</button>
                <span className="text-white font-black">{bet} RUB</span>
                <button onClick={() => setBet(bet+10)} className="w-8 h-8 bg-slate-800 rounded-full">+</button>
            </div>
            <button onClick={() => setBet(bet*2)} className="text-xs font-bold text-blue-400">X2</button>
        </div>
        <button 
            onClick={handleFlip}
            disabled={isFlipping}
            className={`w-full py-5 rounded-2xl font-black uppercase tracking-widest ${isFlipping ? 'bg-slate-800' : 'bg-yellow-500 text-yellow-900 shadow-xl shadow-yellow-900/20'}`}
        >БРОСИТЬ МОНЕТУ</button>
      </div>

      <style>{`
        @keyframes coin-spin {
          0% { transform: rotateY(0); }
          100% { transform: rotateY(1800deg); }
        }
        .preserve-3d { transform-style: preserve-3d; }
        .rotate-y-180 { transform: rotateY(180deg); }
      `}</style>
    </div>
  );
};

export default CoinFlip;
