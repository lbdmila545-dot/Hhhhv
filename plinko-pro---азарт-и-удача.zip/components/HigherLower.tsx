
import React, { useState } from 'react';

interface HigherLowerProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const CARDS = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
const SUITS = ['♠️', '♥️', '♣️', '♦️'];

const HigherLower: React.FC<HigherLowerProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [currentCard, setCurrentCard] = useState({ val: 5, label: '6', suit: '♠️' });
  const [isFlipping, setIsFlipping] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [winMessage, setWinMessage] = useState<string | null>(null);

  const startGame = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setWinMessage(null);
    const initialVal = Math.floor(Math.random() * 13);
    setCurrentCard({ val: initialVal, label: CARDS[initialVal], suit: SUITS[Math.floor(Math.random() * 4)] });
  };

  const guess = (type: 'HIGHER' | 'LOWER') => {
    if (isFlipping) return;
    setIsFlipping(true);
    setWinMessage(null);

    setTimeout(() => {
      const nextVal = Math.floor(Math.random() * 13);
      const nextCard = { val: nextVal, label: CARDS[nextVal], suit: SUITS[Math.floor(Math.random() * 4)] };
      
      let win = false;
      if (type === 'HIGHER' && nextVal >= currentCard.val) win = true;
      if (type === 'LOWER' && nextVal <= currentCard.val) win = true;

      if (win) {
        const winAmt = Math.floor(bet * 1.9);
        onBalanceChange(winAmt);
        setWinMessage(`УГАДАЛ! +${winAmt} RUB`);
      } else {
        setWinMessage('ПРОМАХ!');
        setIsPlaying(false);
      }

      setCurrentCard(nextCard);
      setIsFlipping(false);
    }, 600);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#061a12] text-white">
      <div className="flex justify-between items-center p-4 bg-emerald-950/40 border-b border-emerald-500/20">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center active:scale-90">
            <i className="fas fa-arrow-left"></i>
        </button>
        <span className="font-black italic uppercase text-emerald-400 tracking-tighter">HIGHER LOWER</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className={`w-40 h-60 bg-white rounded-2xl flex flex-col items-center justify-center text-5xl font-black shadow-2xl transition-all duration-500 ${isFlipping ? 'scale-0' : 'scale-100'}`}>
          <div className="absolute top-4 left-4 text-xs text-black flex items-center gap-1">
              <span>{currentCard.label}</span>
              <span>{currentCard.suit}</span>
          </div>
          <div className="text-black">{currentCard.label}</div>
          <div className="text-4xl mt-2">{currentCard.suit}</div>
          <div className="absolute bottom-4 right-4 text-xs text-black rotate-180 flex items-center gap-1">
              <span>{currentCard.label}</span>
              <span>{currentCard.suit}</span>
          </div>
        </div>

        <div className="h-20 mt-8 flex flex-col items-center justify-center text-center">
            {winMessage && (
                <div className={`text-2xl font-black uppercase ${winMessage.includes('УГАДАЛ') ? 'text-emerald-400' : 'text-red-500'}`}>
                    {winMessage}
                </div>
            )}
        </div>
      </div>

      <div className="p-8 bg-slate-900 rounded-t-[40px] space-y-4">
        {!isPlaying ? (
            <div className="space-y-4">
                <div className="bg-black/40 p-4 rounded-3xl border border-slate-800 flex items-center justify-between">
                    <button onClick={() => setBet(Math.max(10, bet - 10))} className="text-emerald-400 font-black text-2xl px-4">-</button>
                    <span className="text-lg font-black">{bet} RUB</span>
                    <button onClick={() => setBet(bet + 10)} className="text-emerald-400 font-black text-2xl px-4">+</button>
                </div>
                <button onClick={startGame} className="w-full h-16 bg-emerald-600 rounded-2xl font-black uppercase shadow-xl shadow-emerald-900/40 active:scale-95">
                    НАЧАТЬ ИГРУ
                </button>
            </div>
        ) : (
            <div className="flex gap-4">
                <button onClick={() => guess('LOWER')} className="flex-1 h-20 bg-red-600/20 border border-red-600/50 rounded-2xl flex flex-col items-center justify-center active:scale-95">
                    <i className="fas fa-chevron-down text-red-500 text-xl mb-1"></i>
                    <span className="text-xs font-black uppercase">МЕНЬШЕ</span>
                </button>
                <button onClick={() => guess('HIGHER')} className="flex-1 h-20 bg-emerald-600/20 border border-emerald-600/50 rounded-2xl flex flex-col items-center justify-center active:scale-95">
                    <i className="fas fa-chevron-up text-emerald-500 text-xl mb-1"></i>
                    <span className="text-xs font-black uppercase">БОЛЬШЕ</span>
                </button>
            </div>
        )}
      </div>
    </div>
  );
};

export default HigherLower;
