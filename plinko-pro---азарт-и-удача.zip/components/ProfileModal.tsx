
import React from 'react';
import { UserProfile, HistoryItem } from '../types.ts';

interface ProfileModalProps {
  user: UserProfile | null;
  balance: number;
  history: HistoryItem[];
  onClose: () => void;
  onDeposit: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ user, balance, history, onClose, onDeposit }) => {
  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex flex-col animate-in fade-in duration-300">
      <div className="p-4 flex justify-between items-center border-b border-slate-800">
        <h2 className="text-xl font-black uppercase italic tracking-tighter">Личный кабинет</h2>
        <button onClick={onClose} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-times"></i></button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar">
        <div className="flex items-center gap-6 bg-slate-900/50 p-6 rounded-3xl border border-slate-800">
          <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center text-3xl font-black shadow-2xl">
            {user?.email[0].toUpperCase()}
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-slate-500 uppercase">{user?.email}</span>
            <span className="text-2xl font-black italic tracking-tighter">ID: {user?.id}</span>
            <div className="flex items-center gap-2 mt-2">
               <span className="px-2 py-0.5 bg-blue-600 rounded text-[9px] font-black">LEVEL {user?.level}</span>
               <span className="text-[9px] text-slate-400 font-bold uppercase">{user?.xp.toFixed(0)} / {(user?.level || 1) * 1000} XP</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
            <div className="text-[10px] text-slate-500 font-black uppercase mb-1">Баланс</div>
            <div className="text-xl font-black text-blue-400">{balance.toLocaleString()} <span className="text-[10px]">RUB</span></div>
          </div>
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800">
            <div className="text-[10px] text-slate-500 font-black uppercase mb-1">Выиграно</div>
            <div className="text-xl font-black text-green-400">{user?.totalWon.toLocaleString()} <span className="text-[10px]">RUB</span></div>
          </div>
        </div>

        <button onClick={onDeposit} className="w-full h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl font-black uppercase shadow-xl shadow-blue-900/20">
           Пополнить счет
        </button>

        <div className="space-y-4">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-500">Последние игры</h3>
          {history.length > 0 ? history.map(item => (
            <div key={item.id} className="bg-slate-900/30 p-4 rounded-2xl border border-slate-800 flex justify-between items-center">
              <div className="flex flex-col">
                <span className="text-xs font-black uppercase italic">{item.game}</span>
                <span className="text-[9px] text-slate-500">{new Date(item.date).toLocaleTimeString()}</span>
              </div>
              <span className={`font-black ${item.type === 'win' ? 'text-green-500' : 'text-red-500'}`}>
                {item.type === 'win' ? '+' : '-'}{item.amount.toLocaleString()}
              </span>
            </div>
          )) : (
            <div className="text-center py-12 text-slate-600 font-bold uppercase text-xs">История пуста</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;
