
import React, { useState } from 'react';

interface LimboProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Limbo: React.FC<LimboProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [target, setTarget] = useState(2.0);
  const [result, setResult] = useState<number | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);

  const play = () => {
    if (balance < bet || isSpinning) return;
    onBalanceChange(-bet);
    setIsSpinning(true);
    setResult(null);

    setTimeout(() => {
      // Алгоритм генерации множителя (аналог Crash)
      const r = Math.random();
      const outcome = parseFloat((0.99 / (1 - r)).toFixed(2));
      setResult(outcome);
      setIsSpinning(false);

      if (outcome >= target) {
        onBalanceChange(Math.floor(bet * target));
      }
    }, 500);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#1a050f] text-white p-6">
      <div className="flex justify-between items-center mb-8">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-pink-500">LIMBO PRO</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className={`text-6xl font-black italic transition-all duration-300 ${
          result === null ? 'text-slate-600' : result >= target ? 'text-green-400 scale-110' : 'text-red-500'
        }`}>
          {result === null ? '?.??' : `${result.toFixed(2)}x`}
        </div>
        <div className="text-[10px] font-black uppercase text-slate-500 tracking-widest mt-4">ВЫПАВШИЙ МНОЖИТЕЛЬ</div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-6 shadow-2xl">
        <div className="grid grid-cols-2 gap-4">
           <div className="bg-black/40 p-4 rounded-2xl border border-slate-700">
              <span className="text-[9px] text-slate-500 uppercase font-black">СТАВКА</span>
              <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value))} className="w-full bg-transparent text-xl font-black outline-none" />
           </div>
           <div className="bg-black/40 p-4 rounded-2xl border border-slate-700">
              <span className="text-[9px] text-slate-500 uppercase font-black">ЦЕЛЬ x</span>
              <input type="number" step="0.1" value={target} onChange={e => setTarget(parseFloat(e.target.value))} className="w-full bg-transparent text-xl font-black outline-none text-pink-400" />
           </div>
        </div>
        
        <button 
          onClick={play} 
          disabled={isSpinning || balance < bet}
          className="w-full h-16 bg-pink-600 text-white font-black uppercase rounded-2xl shadow-xl shadow-pink-900/40 active:scale-95 disabled:opacity-50"
        >
          {isSpinning ? 'ПРОВЕРКА...' : 'ИГРАТЬ'}
        </button>
      </div>
    </div>
  );
};

export default Limbo;
