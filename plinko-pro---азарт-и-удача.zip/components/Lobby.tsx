
import React from 'react';
import { GameView } from '../types.ts';

interface LobbyProps {
  onSelectGame: (view: GameView) => void;
  onClaimBonus: () => void;
  onDaily: () => void;
  onShowLeaderboard: () => void;
}

const Lobby: React.FC<LobbyProps> = ({ onSelectGame, onClaimBonus, onDaily, onShowLeaderboard }) => {
  const games: { id: GameView, name: string, icon: string, color: string, tag?: string }[] = [
    { id: 'CRASH', name: 'CRASH PRO', icon: 'fa-chart-line', color: 'from-red-600/20 to-black', tag: 'HOT' },
    { id: 'ROULETTE', name: 'ROULETTE', icon: 'fa-circle-notch', color: 'from-green-600/20 to-black', tag: 'NEW' },
    { id: 'BLACKJACK', name: 'BLACKJACK', icon: 'fa-spade', color: 'from-blue-600/20 to-black', tag: 'NEW' },
    { id: 'MINES', name: 'MINES PRO', icon: 'fa-bomb', color: 'from-blue-900 to-black', tag: 'BEST' },
    { id: 'CASES', name: 'CASES', icon: 'fa-box-open', color: 'from-yellow-600/20 to-black', tag: 'NEW' },
    { id: 'SLIDERDICE', name: 'SLIDER DICE', icon: 'fa-sliders', color: 'from-indigo-600/20 to-black', tag: 'NEW' },
    { id: 'TOWER', name: 'TOWER', icon: 'fa-building', color: 'from-orange-600/20 to-black', tag: 'NEW' },
    { id: 'BACCARAT', name: 'BACCARAT', icon: 'fa-crown', color: 'from-purple-600/20 to-black', tag: 'NEW' },
    { id: 'CRYPT', name: 'CRYPT', icon: 'fa-skull', color: 'from-emerald-900/30 to-black', tag: 'NEW' },
    { id: 'GOAL', name: 'GOAL PRO', icon: 'fa-goal-net', color: 'from-green-900/40 to-black', tag: 'NEW' },
    { id: 'PLUMBER', name: 'PLUMBER', icon: 'fa-faucet-drip', color: 'from-cyan-900/30 to-black', tag: 'NEW' },
    { id: 'THIMBLES', name: 'THIMBLES', icon: 'fa-cup-trowel', color: 'from-amber-600/20 to-black' },
    { id: 'APPLE', name: 'APPLE FORTUNE', icon: 'fa-apple-whole', color: 'from-red-900/40 to-black' },
    { id: 'STAIRS', name: 'STAIRS', icon: 'fa-stairs', color: 'from-purple-900/30 to-black' },
    { id: 'SCRATCH', name: 'SCRATCH', icon: 'fa-note-sticky', color: 'from-yellow-600/20 to-black' },
    { id: 'KENO', name: 'KENO', icon: 'fa-list-ol', color: 'from-cyan-900/30 to-black' },
    { id: 'PLINKO', name: 'PLINKO', icon: 'fa-braille', color: 'from-blue-600/20 to-black' },
  ];

  return (
    <div className="p-4 space-y-6 pb-24 h-full overflow-y-auto no-scrollbar">
      <div className="relative w-full h-44 rounded-3xl overflow-hidden shadow-2xl group border border-blue-500/20 active:scale-95 transition-transform" onClick={onClaimBonus}>
        <img src="https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=800" alt="Banner" className="w-full h-full object-cover opacity-80" />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/90 via-blue-900/40 to-transparent flex flex-col justify-center p-6">
          <span className="text-[10px] font-black uppercase text-blue-400 mb-1">Фрибет за регистрацию</span>
          <h2 className="text-3xl font-black italic leading-none text-white">120,000 <span className="text-sm">RUB</span></h2>
          <button className="mt-3 w-fit px-6 py-2 bg-blue-600 rounded-full text-xs font-black uppercase shadow-lg">Забрать</button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {games.map(game => (
          <button 
            key={game.id}
            onClick={() => onSelectGame(game.id)} 
            className={`group relative h-32 rounded-2xl overflow-hidden bg-gradient-to-br ${game.color} border border-white/5 flex flex-col active:scale-95 transition-all shadow-lg`}
          >
            {game.tag && (
              <div className={`absolute top-1 right-1 z-10 ${game.tag === 'NEW' ? 'bg-green-600' : 'bg-blue-600'} text-[8px] font-black px-1.5 py-0.5 rounded uppercase`}>
                {game.tag}
              </div>
            )}
            <div className="flex-1 flex items-center justify-center">
               <i className={`fas ${game.icon} text-4xl text-white/40 group-hover:text-white/80 group-hover:scale-110 transition-all duration-500`}></i>
            </div>
            <div className="p-2 bg-slate-900/80 text-center">
              <span className="text-[9px] font-black uppercase italic tracking-tighter text-slate-300">{game.name}</span>
            </div>
          </button>
        ))}
      </div>

      <div className="flex gap-3">
         <button onClick={onDaily} className="flex-1 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl font-black uppercase text-xs shadow-xl active:scale-95">
            <i className="fas fa-gift mr-2"></i> Бонус
         </button>
         <button onClick={onShowLeaderboard} className="flex-1 py-4 bg-slate-800 border border-slate-700 rounded-2xl font-black uppercase text-xs active:scale-95">
            <i className="fas fa-trophy mr-2 text-yellow-500"></i> Топ-100
         </button>
      </div>
    </div>
  );
};

export default Lobby;