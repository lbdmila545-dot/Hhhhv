
import React, { useState } from 'react';

interface ScratchCardsProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const SYMBOLS = ['💎', '🍒', '🍋', '🔔', '7️⃣', '🍀'];

const ScratchCards: React.FC<ScratchCardsProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isPlaying, setIsPlaying] = useState(false);
  const [revealed, setRevealed] = useState<boolean[]>(Array(9).fill(false));
  const [grid, setGrid] = useState<string[]>([]);
  const [message, setMessage] = useState<string | null>(null);

  const startScratch = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setRevealed(Array(9).fill(false));
    setMessage(null);
    
    // Генерируем случайную сетку
    const newGrid = Array(9).fill(0).map(() => SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]);
    setGrid(newGrid);
  };

  const reveal = (idx: number) => {
    if (!isPlaying || revealed[idx]) return;
    const newRevealed = [...revealed];
    newRevealed[idx] = true;
    setRevealed(newRevealed);

    if (newRevealed.every(v => v)) {
      checkResult(newRevealed);
    }
  };

  const checkResult = (finalRevealed: boolean[]) => {
    const counts: Record<string, number> = {};
    grid.forEach(s => counts[s] = (counts[s] || 0) + 1);
    
    let winMult = 0;
    Object.entries(counts).forEach(([sym, count]) => {
      if (count >= 3) winMult += (SYMBOLS.indexOf(sym) + 1) * 2;
    });

    if (winMult > 0) {
      const win = Math.floor(bet * winMult);
      onBalanceChange(win);
      setMessage(`ВЫИГРЫШ: +${win} RUB!`);
    } else {
      setMessage('БЕЗ ВЫИГРЫША');
    }
    setIsPlaying(false);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#121212] text-white p-6">
      <div className="flex justify-between items-center mb-8">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-yellow-500">SCRATCH CARD</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="grid grid-cols-3 gap-2 bg-slate-900 p-3 rounded-2xl border-4 border-slate-800 shadow-2xl w-full max-w-sm">
          {Array(9).fill(0).map((_, i) => (
            <div 
              key={i} 
              onClick={() => reveal(i)}
              className={`aspect-square rounded-xl flex items-center justify-center text-3xl cursor-pointer transition-all duration-300 ${
                revealed[i] ? 'bg-slate-800 rotate-y-180' : 'bg-gradient-to-br from-slate-400 to-slate-600 shadow-inner'
              }`}
            >
              {revealed[i] ? grid[i] : <i className="fas fa-star text-white/30 text-xl"></i>}
            </div>
          ))}
        </div>
        
        {message && <div className="mt-8 text-2xl font-black uppercase text-yellow-500 animate-bounce">{message}</div>}
      </div>

      <div className="bg-slate-900 p-6 rounded-t-[40px] space-y-4">
        <div className="flex justify-between items-center bg-black/40 p-4 rounded-2xl">
          <button onClick={() => setBet(Math.max(10, bet-10))} disabled={isPlaying} className="text-yellow-500 text-2xl font-black">-</button>
          <span className="font-black">{bet} RUB</span>
          <button onClick={() => setBet(bet+10)} disabled={isPlaying} className="text-yellow-500 text-2xl font-black">+</button>
        </div>
        <button 
          onClick={startScratch} 
          disabled={isPlaying || balance < bet}
          className="w-full h-16 bg-yellow-500 text-black font-black uppercase rounded-2xl shadow-xl active:scale-95 disabled:opacity-50"
        >
          КУПИТЬ КАРТУ
        </button>
      </div>
    </div>
  );
};

export default ScratchCards;
