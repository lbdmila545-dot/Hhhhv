
import React from 'react';

interface BetControlsProps {
  betAmount: number;
  onBetChange: (amount: number) => void;
  onPlay: () => boolean;
  isAutoPlaying: boolean;
  onToggleAuto: () => void;
  balance: number;
}

const BetControls: React.FC<BetControlsProps> = ({ betAmount, onBetChange, onPlay, isAutoPlaying, onToggleAuto, balance }) => {
  return (
    <div className="p-3 bg-slate-900 border-t border-slate-800 space-y-2 flex-shrink-0">
      <div className="flex gap-1">
         {[10, 100, 500, 'MAX'].map(v => (
           <button key={v} onClick={() => onBetChange(v === 'MAX' ? Math.floor(balance) : Number(v))} className="flex-1 bg-slate-800 py-1.5 rounded-lg text-[10px] font-black text-slate-400 border border-slate-700">{v}</button>
         ))}
      </div>
      <div className="flex items-center gap-2">
        <div className="flex-1 bg-black rounded-xl border border-slate-700 flex items-center px-3 py-2">
          <input type="number" value={betAmount} onChange={e => onBetChange(parseInt(e.target.value) || 0)} className="bg-transparent w-full text-sm font-black outline-none" />
          <span className="text-[10px] font-black text-slate-500">RUB</span>
        </div>
        <button onClick={onToggleAuto} className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${isAutoPlaying ? 'bg-orange-500' : 'bg-slate-800 text-slate-500'}`}><i className="fas fa-sync-alt"></i></button>
        <button onClick={onPlay} disabled={balance < betAmount} className="flex-[1.2] h-11 bg-green-600 rounded-xl font-black text-xs uppercase shadow-lg shadow-green-900/20 active:scale-95">Ставка</button>
      </div>
    </div>
  );
};

export default BetControls;
