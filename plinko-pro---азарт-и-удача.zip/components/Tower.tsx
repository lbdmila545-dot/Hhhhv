
import React, { useState } from 'react';

interface TowerProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Tower: React.FC<TowerProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [level, setLevel] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const multipliers = [1.2, 1.5, 2.0, 2.8, 3.5, 4.8, 6.2, 8.5, 12.0, 20.0];

  const startGame = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setLevel(0);
    setGameOver(false);
  };

  const choose = (idx: number) => {
    if (!isPlaying || gameOver) return;
    const isWin = Math.random() > 0.3; // 70% шанс успеха
    if (isWin) {
      if (level === multipliers.length - 1) {
        takeWin();
      } else {
        setLevel(level + 1);
      }
    } else {
      setIsPlaying(false);
      setGameOver(true);
    }
  };

  const takeWin = () => {
    if (level === 0) return;
    const win = Math.floor(bet * multipliers[level - 1]);
    onBalanceChange(win);
    setIsPlaying(false);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0f1e] text-white">
      <div className="flex justify-between items-center p-4 bg-black/40 border-b border-orange-500/20">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-orange-500 uppercase">TOWER PRO</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col-reverse gap-1 no-scrollbar">
        {multipliers.map((m, i) => (
          <div key={i} className={`flex gap-1 h-10 transition-all ${i === level ? 'scale-105' : i < level ? 'opacity-40' : 'opacity-100'}`}>
            {[0,1,2].map(box => (
              <button 
                key={box} 
                onClick={() => choose(box)} 
                disabled={i !== level || !isPlaying}
                className={`flex-1 rounded border-2 transition-all ${i === level && isPlaying ? 'bg-orange-600/40 border-orange-500' : 'bg-slate-800 border-slate-700'}`}
              >
                {i < level ? <i className="fas fa-check text-green-500 text-xs"></i> : ''}
              </button>
            ))}
            <div className="w-12 bg-black/40 flex items-center justify-center text-[10px] font-black italic">x{m}</div>
          </div>
        ))}
      </div>

      <div className="p-8 bg-slate-900 rounded-t-[40px] space-y-4">
        {!isPlaying ? (
           <>
            <input 
              type="number" 
              value={bet} 
              onChange={e => setBet(parseInt(e.target.value) || 0)} 
              className="w-full bg-black/40 p-4 rounded-2xl border border-slate-800 font-black text-center outline-none" 
            />
            <button onClick={startGame} className="w-full h-16 bg-orange-600 rounded-2xl font-black uppercase shadow-xl active:scale-95">ИГРАТЬ</button>
           </>
        ) : (
          <button onClick={takeWin} className="w-full h-16 bg-green-600 rounded-2xl font-black uppercase flex flex-col items-center justify-center active:scale-95">
             <span className="text-[10px] opacity-70">ЗАБРАТЬ</span>
             <span>{(bet * (level > 0 ? multipliers[level-1] : 1)).toFixed(0)} RUB</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default Tower;
