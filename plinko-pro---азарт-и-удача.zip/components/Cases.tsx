
import React, { useState } from 'react';

interface CasesProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Cases: React.FC<CasesProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(100);
  const [isOpening, setIsOpening] = useState(false);
  const [prize, setPrize] = useState<number | null>(null);

  const openCase = () => {
    if (balance < bet || isOpening) return;
    onBalanceChange(-bet);
    setIsOpening(true);
    setPrize(null);

    setTimeout(() => {
      const multipliers = [0.1, 0.5, 1.2, 1.5, 2, 5, 10, 50];
      const weights = [30, 25, 15, 10, 10, 5, 4, 1];
      
      let totalWeight = weights.reduce((a, b) => a + b, 0);
      let random = Math.random() * totalWeight;
      let current = 0;
      let winner = 0;

      for (let i = 0; i < weights.length; i++) {
        current += weights[i];
        if (random <= current) {
          winner = multipliers[i];
          break;
        }
      }

      setPrize(winner);
      setIsOpening(false);
      onBalanceChange(Math.floor(bet * winner));
    }, 1500);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#1a140a] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-yellow-600 uppercase">CASES PRO</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className={`w-56 h-40 bg-gradient-to-br from-yellow-700 to-yellow-900 rounded-3xl border-4 border-yellow-600 shadow-2xl flex items-center justify-center text-4xl font-black relative overflow-hidden ${isOpening ? 'animate-bounce' : ''}`}>
           {isOpening ? <i className="fas fa-spinner animate-spin"></i> : prize !== null ? `x${prize}` : <i className="fas fa-briefcase"></i>}
        </div>
        
        {prize !== null && (
          <div className={`mt-8 text-3xl font-black uppercase italic ${prize >= 1 ? 'text-green-400' : 'text-red-500'}`}>
            {prize >= 1 ? 'ВЫИГРЫШ!' : 'ПРОИГРЫШ'}
          </div>
        )}
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4">
        <div className="flex items-center gap-4 bg-black/40 p-4 rounded-2xl border border-slate-800">
           <span className="text-xs font-black text-slate-500">RUB</span>
           <input 
             type="number" 
             value={bet} 
             onChange={e => setBet(parseInt(e.target.value) || 0)} 
             className="bg-transparent text-xl font-black outline-none w-full"
           />
        </div>
        <button onClick={openCase} disabled={isOpening || balance < bet} className="w-full h-16 bg-yellow-600 rounded-2xl font-black uppercase shadow-xl active:scale-95 disabled:opacity-50">ОТКРЫТЬ КЕЙС</button>
      </div>
    </div>
  );
};

export default Cases;
