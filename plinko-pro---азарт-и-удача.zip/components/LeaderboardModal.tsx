
import React from 'react';

const LeaderboardModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const leaders = [
    { name: 'X_Gambit_99', win: 15400000, level: 84 },
    { name: 'JackpotKing', win: 12100500, level: 79 },
    { name: 'User_4421', win: 8900000, level: 65 },
    { name: 'LuckyStrike', win: 5400200, level: 58 },
    { name: 'ProPlayer_1X', win: 3200000, level: 44 },
    { name: 'MinerExpert', win: 1500000, level: 32 },
    { name: 'CoinMaster', win: 950000, level: 21 },
    { name: 'DiceLover', win: 450000, level: 15 },
  ];

  return (
    <div className="fixed inset-0 z-[200] bg-black/90 backdrop-blur-md flex flex-col animate-in slide-in-from-right duration-500">
      <div className="p-4 flex justify-between items-center border-b border-slate-800">
        <h2 className="text-xl font-black uppercase italic tracking-tighter">Топ игроков</h2>
        <button onClick={onClose} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-times"></i></button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
        {leaders.map((player, i) => (
          <div key={i} className={`p-4 rounded-2xl border flex justify-between items-center ${
            i === 0 ? 'bg-yellow-500/10 border-yellow-500' : 
            i === 1 ? 'bg-slate-300/10 border-slate-300' :
            i === 2 ? 'bg-orange-600/10 border-orange-600' : 'bg-slate-900 border-slate-800'
          }`}>
            <div className="flex items-center gap-4">
              <span className={`text-xl font-black italic w-6 ${
                i === 0 ? 'text-yellow-500' : i === 1 ? 'text-slate-300' : i === 2 ? 'text-orange-600' : 'text-slate-600'
              }`}>{i + 1}</span>
              <div className="flex flex-col">
                <span className="text-sm font-black">{player.name}</span>
                <span className="text-[9px] text-slate-500 font-bold uppercase">LVL {player.level}</span>
              </div>
            </div>
            <span className="font-mono font-black text-blue-400">{player.win.toLocaleString()} RUB</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LeaderboardModal;
