
import React, { useState } from 'react';

interface StairsProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const MULTIPLIERS = [10.5, 7.2, 5.1, 3.8, 2.9, 2.1, 1.6, 1.25];

const Stairs: React.FC<StairsProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [currentRow, setCurrentRow] = useState(-1);
  const [grid, setGrid] = useState<(null | 'win' | 'lose')[][]>(Array(8).fill(null).map(() => Array(4).fill(null)));
  const [isPlaying, setIsPlaying] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const startGame = () => {
    if (balance < bet) return;
    onBalanceChange(-bet);
    setIsPlaying(true);
    setCurrentRow(0);
    setGrid(Array(8).fill(null).map(() => Array(4).fill(null)));
    setMessage(null);
  };

  const step = (colIdx: number) => {
    if (!isPlaying || currentRow === -1) return;

    const isWin = Math.random() > 0.25; // 75% шанс успеха на каждой ступеньке
    const newGrid = [...grid];
    const rowIdx = grid.length - 1 - currentRow;
    
    if (isWin) {
      newGrid[rowIdx][colIdx] = 'win';
      if (currentRow === 7) {
        takeWin();
      } else {
        setCurrentRow(prev => prev + 1);
      }
    } else {
      newGrid[rowIdx][colIdx] = 'lose';
      setIsPlaying(false);
      setMessage('ПАДЕНИЕ!');
    }
    setGrid(newGrid);
  };

  const takeWin = () => {
    if (currentRow <= 0) return;
    const winAmt = Math.floor(bet * MULTIPLIERS[MULTIPLIERS.length - currentRow]);
    onBalanceChange(winAmt);
    setIsPlaying(false);
    setMessage(`ВЫИГРЫШ: +${winAmt} RUB`);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#1e142e] text-white">
      <div className="flex justify-between items-center p-4 bg-black/40 border-b border-purple-500/20">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-purple-400">STAIRS PRO</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center no-scrollbar">
        <div className="flex flex-col gap-2 w-full max-w-xs">
           {grid.map((row, rIdx) => {
             const rowIdxFromBottom = grid.length - 1 - rIdx;
             const isRowActive = isPlaying && rowIdxFromBottom === currentRow;
             return (
               <div key={rIdx} className={`flex gap-2 h-12 transition-all ${isRowActive ? 'scale-105 z-10' : 'opacity-60'}`}>
                  {row.map((cell, cIdx) => (
                    <button 
                      key={cIdx} 
                      onClick={() => step(cIdx)} 
                      disabled={!isRowActive}
                      className={`flex-1 rounded-lg border-2 flex items-center justify-center transition-all ${
                        cell === 'win' ? 'bg-green-600 border-green-400' : 
                        cell === 'lose' ? 'bg-red-600 border-red-400' : 
                        isRowActive ? 'bg-purple-600/40 border-purple-500 animate-pulse' : 'bg-slate-800 border-slate-700'
                      }`}
                    >
                       {cell === 'win' && <i className="fas fa-check text-white"></i>}
                       {cell === 'lose' && <i className="fas fa-times text-white"></i>}
                    </button>
                  ))}
                  <div className="w-16 flex items-center justify-center bg-black/40 rounded text-[10px] font-black italic">
                    x{MULTIPLIERS[rIdx].toFixed(2)}
                  </div>
               </div>
             );
           })}
        </div>

        {message && <div className={`mt-8 text-2xl font-black uppercase italic ${message.includes('ВЫИГРЫШ') ? 'text-green-400' : 'text-red-500'}`}>{message}</div>}
      </div>

      <div className="p-8 bg-slate-900 rounded-t-[40px] space-y-4 shadow-2xl">
        <div className="flex items-center gap-3">
            {!isPlaying ? (
              <>
                <div className="flex-1 bg-black/40 p-3 rounded-2xl flex flex-col items-center">
                   <span className="text-[10px] text-slate-500 font-black">СТАВКА</span>
                   <span className="text-lg font-black">{bet} RUB</span>
                </div>
                <button onClick={startGame} className="flex-[2] h-16 bg-purple-600 rounded-2xl font-black uppercase">ИГРАТЬ</button>
              </>
            ) : (
              <button onClick={takeWin} className="w-full h-16 bg-green-600 rounded-2xl font-black uppercase flex flex-col items-center justify-center">
                <span className="text-[10px] opacity-70">ЗАБРАТЬ</span>
                <span>{(bet * (currentRow > 0 ? MULTIPLIERS[MULTIPLIERS.length - currentRow] : 1)).toFixed(0)} RUB</span>
              </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default Stairs;
