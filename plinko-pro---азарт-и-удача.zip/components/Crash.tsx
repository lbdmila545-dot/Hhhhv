
import React, { useState, useEffect, useRef } from 'react';

interface CrashProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Crash: React.FC<CrashProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [status, setStatus] = useState<'IDLE' | 'PLAYING' | 'CRASHED'>('IDLE');
  const [multiplier, setMultiplier] = useState(1.0);
  const [crashPoint, setCrashPoint] = useState(0);
  const [isCashedOut, setIsCashedOut] = useState(false);
  const [cashoutAmount, setCashoutAmount] = useState(0);

  const requestRef = useRef<number>();
  const startTimeRef = useRef<number>(0);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const oscRef = useRef<OscillatorNode | null>(null);
  const gainRef = useRef<GainNode | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const startCrashSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(200, ctx.currentTime);
    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    oscRef.current = osc;
    gainRef.current = gain;
  };

  const updateCrashSound = (mult: number) => {
    if (oscRef.current && audioCtxRef.current) {
        oscRef.current.frequency.setValueAtTime(200 + (mult * 50), audioCtxRef.current.currentTime);
    }
  };

  const stopCrashSound = (isCrash: boolean) => {
    if (oscRef.current && gainRef.current && audioCtxRef.current) {
        const ctx = audioCtxRef.current;
        if (isCrash) {
            oscRef.current.type = 'sawtooth';
            oscRef.current.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.1);
            gainRef.current.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
        } else {
            gainRef.current.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
        }
        setTimeout(() => {
            oscRef.current?.stop();
            oscRef.current = null;
        }, 300);
    }
  };

  const startRound = () => {
    initAudio();
    if (balance < bet) return;
    onBalanceChange(-bet);
    setStatus('PLAYING');
    setIsCashedOut(false);
    setMultiplier(1.0);
    const r = Math.random();
    const point = Math.max(1, 0.99 / (1 - r));
    setCrashPoint(point);
    startTimeRef.current = performance.now();
    startCrashSound();
    requestRef.current = requestAnimationFrame(animate);
  };

  const animate = (time: number) => {
    const elapsed = (time - startTimeRef.current) / 1000;
    const currentMult = Math.pow(1.04, elapsed * 5); 
    if (currentMult >= crashPoint) {
      setMultiplier(crashPoint);
      setStatus('CRASHED');
      stopCrashSound(true);
      cancelAnimationFrame(requestRef.current!);
    } else {
      setMultiplier(currentMult);
      updateCrashSound(currentMult);
      requestRef.current = requestAnimationFrame(animate);
    }
  };

  const cashOut = () => {
    if (status !== 'PLAYING' || isCashedOut) return;
    const win = Math.floor(bet * multiplier);
    setCashoutAmount(win);
    setIsCashedOut(true);
    onBalanceChange(win);
    stopCrashSound(false);
    initAudio();
    const ctx = audioCtxRef.current!;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.2);
  };

  useEffect(() => {
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      if (oscRef.current) oscRef.current.stop();
    };
  }, []);

  return (
    <div className="flex flex-col h-full w-full bg-[#050505] text-white overflow-hidden">
      <div className="flex justify-between items-center p-3 bg-slate-900/80 border-b border-red-500/20 flex-shrink-0">
        <button onClick={onBack} className="w-9 h-9 bg-slate-800 rounded-xl flex items-center justify-center active:scale-90">
            <i className="fas fa-arrow-left text-sm"></i>
        </button>
        <span className="font-black italic uppercase text-red-500 tracking-tighter text-sm">CRASH PRO</span>
        <div className="w-9"></div>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center p-4 min-h-0">
        <div className={`text-6xl font-black italic transition-all duration-75 ${
          status === 'CRASHED' ? 'text-red-600 scale-110' : status === 'PLAYING' ? 'text-green-400' : 'text-slate-600'
        }`}>
          {multiplier.toFixed(2)}x
        </div>
        {status === 'CRASHED' && (
          <div className="mt-2 text-red-600 font-black uppercase text-[10px] tracking-widest animate-bounce">CRASHED!</div>
        )}
        {isCashedOut && (
          <div className="mt-2 text-green-400 font-black uppercase text-[10px] tracking-widest">
            ВЫВЕДЕНО: +{cashoutAmount} RUB
          </div>
        )}
        <div className="w-full h-32 mt-6 relative flex items-end min-h-[120px]">
           <div className="absolute inset-0 border-l border-b border-slate-800/50"></div>
           <svg className="w-full h-full">
             <path 
                d={`M 0 128 Q ${status === 'PLAYING' ? 80 : 40} 128 ${multiplier * 12} ${128 - (multiplier * 3.5)}`} 
                fill="none" 
                stroke={status === 'CRASHED' ? '#dc2626' : '#22c55e'} 
                strokeWidth="3"
                className="transition-all duration-300"
             />
           </svg>
        </div>
      </div>
      <div className="p-4 bg-slate-900 rounded-t-3xl shadow-2xl space-y-3 flex-shrink-0">
        <div className="flex gap-2">
            <div className="flex-1 bg-black/60 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[8px] text-slate-500 uppercase font-black mb-1 text-center">СТАВКА</div>
                <div className="flex items-center justify-center gap-2">
                    <button onClick={() => setBet(Math.max(10, bet - 10))} disabled={status === 'PLAYING'} className="text-red-500 font-black text-lg w-6">-</button>
                    <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value) || 0)} disabled={status === 'PLAYING'} className="bg-transparent text-center font-black text-sm w-16 outline-none" />
                    <button onClick={() => setBet(Math.min(balance, bet + 10))} disabled={status === 'PLAYING'} className="text-red-500 font-black text-lg w-6">+</button>
                </div>
            </div>
            <div className="flex gap-1 flex-1">
                <button onClick={() => setBet(Math.floor(balance))} disabled={status === 'PLAYING'} className="flex-1 bg-slate-800 rounded-lg text-[8px] font-black uppercase">MAX</button>
                <button onClick={() => setBet(Math.max(10, Math.floor(bet/2)))} disabled={status === 'PLAYING'} className="flex-1 bg-slate-800 rounded-lg text-[8px] font-black uppercase">1/2</button>
            </div>
        </div>
        {status !== 'PLAYING' ? (
          <button onClick={startRound} disabled={balance < bet} className="w-full h-12 bg-red-600 rounded-xl font-black uppercase text-xs shadow-lg active:scale-95">
             ПОСТАВИТЬ
          </button>
        ) : (
          <button onClick={cashOut} disabled={isCashedOut} className={`w-full h-12 rounded-xl font-black uppercase text-xs transition-all ${isCashedOut ? 'bg-slate-700 text-slate-500' : 'bg-green-600 active:scale-95'}`}>
             {isCashedOut ? 'ВЫВЕДЕНО' : `ВЫВЕСТИ: ${(bet * multiplier).toFixed(0)} RUB`}
          </button>
        )}
      </div>
    </div>
  );
};

export default Crash;
