
import React, { useState, useRef, useEffect } from 'react';

interface WheelOfFortuneProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

interface Sector {
  label: string;
  mult: number;
  color: string;
}

const SECTORS: Sector[] = [
  { label: 'JACKPOT', mult: 100, color: '#FFD700' }, // Gold
  { label: 'x0.1', mult: 0.1, color: '#334155' },
  { label: 'x2', mult: 2, color: '#ef4444' },
  { label: 'x0.5', mult: 0.5, color: '#334155' },
  { label: 'x5', mult: 5, color: '#3b82f6' },
  { label: 'x0.2', mult: 0.2, color: '#334155' },
  { label: 'x10', mult: 10, color: '#10b981' },
  { label: 'x0.5', mult: 0.5, color: '#334155' },
  { label: 'x1.5', mult: 1.5, color: '#f59e0b' },
  { label: 'x0.1', mult: 0.1, color: '#334155' },
  { label: 'x3', mult: 3, color: '#8b5cf6' },
  { label: 'x0.2', mult: 0.2, color: '#334155' },
  { label: 'x20', mult: 20, color: '#ec4899' },
  { label: 'x0.5', mult: 0.5, color: '#334155' },
  { label: 'x1.2', mult: 1.2, color: '#06b6d4' },
  { label: 'x0.1', mult: 0.1, color: '#334155' },
  { label: 'x7', mult: 7, color: '#f97316' },
  { label: 'x0.2', mult: 0.2, color: '#334155' },
];

const WheelOfFortune: React.FC<WheelOfFortuneProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [lastWin, setLastWin] = useState<number | null>(null);
  
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rotationRef = useRef(0);
  const lastTickAngle = useRef(0);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playTick = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.03);
    gain.gain.setValueAtTime(0.06, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.03);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.03);
  };

  const playWin = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(523, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1046, ctx.currentTime + 0.4);
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.4);
  };

  const handleSpin = () => {
    if (isSpinning) return;
    if (balance < bet) {
      alert("Недостаточно средств! Заберите бонус на главной.");
      return;
    }

    initAudio();
    onBalanceChange(-bet);
    setIsSpinning(true);
    setLastWin(null);

    const sectorAngle = 360 / SECTORS.length;
    const minSpins = 6;
    const randomExtra = Math.random() * 360;
    const targetRotation = rotationRef.current + (360 * minSpins) + randomExtra;
    
    const startTime = performance.now();
    const duration = 5000;

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Инерционное замедление
      const easeOut = 1 - Math.pow(1 - progress, 4);
      const currentRotation = rotationRef.current + (targetRotation - rotationRef.current) * easeOut;
      
      setRotation(currentRotation);

      // Логика звука тиканья
      const tickThreshold = sectorAngle;
      const currentTickIdx = Math.floor(currentRotation / tickThreshold);
      if (currentTickIdx > lastTickAngle.current) {
        playTick();
        lastTickAngle.current = currentTickIdx;
      }

      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        rotationRef.current = currentRotation;
        const finalAngle = currentRotation % 360;
        // Указатель сверху, поэтому считаем индекс от 0 градусов (верха)
        const adjustedAngle = (360 - (finalAngle % 360)) % 360;
        const winnerIndex = Math.floor(adjustedAngle / sectorAngle);
        const sector = SECTORS[winnerIndex % SECTORS.length];
        
        const winAmount = Math.floor(bet * sector.mult);
        if (winAmount > 0) {
          playWin();
          onBalanceChange(winAmount);
        }
        setLastWin(winAmount);
        setIsSpinning(false);
      }
    };

    requestAnimationFrame(animate);
  };

  const canPlay = balance >= bet && !isSpinning;

  return (
    <div className="flex flex-col h-full bg-[#0a0f1e] relative overflow-hidden select-none">
      {/* Background Lights */}
      <div className="absolute inset-0 opacity-30 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[120px]"></div>
      </div>

      <div className="flex justify-between items-center p-4 bg-black/60 border-b border-yellow-600/30 z-20 backdrop-blur-lg">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-full flex items-center justify-center border border-slate-600 active:scale-90 transition-transform">
            <i className="fas fa-arrow-left text-white text-sm"></i>
        </button>
        <div className="flex flex-col items-center">
          <span className="text-xs font-black italic text-yellow-500 uppercase tracking-widest">WHEEL OF FORTUNE</span>
          <span className="text-[8px] text-slate-400 font-bold uppercase">Casino Edition</span>
        </div>
        <div className="w-10" />
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4 relative z-10">
        
        {/* Pointer (Указатель) */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-[180px] z-40 w-12 h-14">
           <div className="w-full h-full bg-red-600 clip-pointer shadow-2xl border-2 border-white/20"></div>
           <div className="absolute top-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-white rounded-full shadow-[0_0_10px_white]"></div>
        </div>

        {/* Wheel Body */}
        <div className="relative w-[340px] h-[340px] flex items-center justify-center">
          
          {/* Outer Ring with Lights */}
          <div className="absolute inset-0 rounded-full border-[15px] border-yellow-500 shadow-[0_0_50px_rgba(234,179,8,0.4),inset_0_0_20px_rgba(0,0,0,0.8)] z-20">
             {Array.from({ length: 18 }).map((_, i) => (
               <div 
                key={i}
                className={`absolute w-3 h-3 rounded-full shadow-[0_0_10px_white] transition-opacity duration-300 ${isSpinning ? 'animate-pulse' : ''}`}
                style={{
                  top: '50%', left: '50%',
                  backgroundColor: i % 2 === 0 ? '#fbbf24' : '#ffffff',
                  transform: `translate(-50%, -50%) rotate(${i * 20}deg) translateY(-158px)`,
                }}
               />
             ))}
          </div>

          {/* The Actual Wheel */}
          <div 
            className="w-[310px] h-[310px] rounded-full overflow-hidden shadow-2xl relative z-10 bg-slate-900 border-4 border-yellow-800"
            style={{ 
              transform: `rotate(${rotation}deg)`,
              transition: isSpinning ? 'none' : 'transform 0.1s ease-out'
            }}
          >
            {/* CSS Conic Gradient Wheel (Reliable) */}
            <div 
              className="absolute inset-0" 
              style={{
                background: `conic-gradient(${SECTORS.map((s, i) => `${s.color} ${(i * 360/SECTORS.length)}deg ${((i+1) * 360/SECTORS.length)}deg`).join(', ')})`
              }}
            />
            
            {/* Sector Labels */}
            {SECTORS.map((s, i) => (
              <div 
                key={i}
                className="absolute top-0 left-1/2 -translate-x-1/2 h-1/2 origin-bottom flex flex-col items-center pt-4"
                style={{ transform: `rotate(${(i * 360/SECTORS.length) + (180/SECTORS.length)}deg)` }}
              >
                <span className={`text-[10px] font-black italic tracking-tighter ${s.label === 'JACKPOT' ? 'text-black bg-yellow-400 px-1 rounded' : 'text-white'}`} style={{ textShadow: '0 2px 4px rgba(0,0,0,0.8)' }}>
                  {s.label}
                </span>
              </div>
            ))}

            {/* Hub */}
            <div className="absolute inset-0 m-auto w-14 h-14 bg-gradient-to-tr from-yellow-700 via-yellow-400 to-yellow-800 rounded-full border-4 border-yellow-900 z-20 shadow-xl flex items-center justify-center">
              <div className="w-4 h-4 bg-white/20 rounded-full animate-ping"></div>
            </div>
          </div>
        </div>

        {/* Win Display Area */}
        <div className="mt-8 h-20 flex flex-col items-center justify-center">
          {lastWin !== null && (
            <>
              <div className={`text-4xl font-black italic tracking-tighter animate-in zoom-in duration-300 ${lastWin > 0 ? 'text-yellow-400 drop-shadow-[0_0_15px_rgba(234,179,8,0.6)]' : 'text-slate-500'}`}>
                {lastWin > 0 ? `+${lastWin.toLocaleString()} RUB` : 'MISS'}
              </div>
              {lastWin > 100 && (
                <div className="text-[10px] font-bold text-yellow-500 uppercase mt-1 animate-pulse">BIG WIN!</div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Control Panel */}
      <div className="p-6 bg-slate-900/90 border-t border-yellow-600/20 backdrop-blur-xl z-30">
        <div className="flex flex-col gap-4 max-w-md mx-auto">
            
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-black/60 rounded-2xl border border-slate-700 p-3 flex items-center justify-between shadow-inner">
                <span className="text-[10px] font-black text-slate-500 uppercase">Ставка</span>
                <div className="flex items-center gap-4">
                   <button onClick={() => setBet(Math.max(10, bet - 10))} disabled={isSpinning} className="text-yellow-500 font-bold text-2xl active:scale-75 transition-transform disabled:opacity-30">-</button>
                   <span className="text-white font-black text-lg min-w-[40px] text-center">{bet}</span>
                   <button onClick={() => setBet(Math.min(balance, bet + 10))} disabled={isSpinning} className="text-yellow-500 font-bold text-2xl active:scale-75 transition-transform disabled:opacity-30">+</button>
                </div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => setBet(Math.min(balance, bet * 2))} disabled={isSpinning} className="bg-slate-800 text-[10px] font-bold px-4 py-3 rounded-xl border border-slate-700 active:bg-slate-700">X2</button>
                <button onClick={() => setBet(10)} disabled={isSpinning} className="bg-slate-800 text-[10px] font-bold px-3 py-3 rounded-xl border border-slate-700 active:bg-slate-700">MIN</button>
              </div>
            </div>

            <button 
                onClick={handleSpin}
                disabled={isSpinning}
                className={`w-full h-16 rounded-2xl font-black text-white uppercase tracking-[0.2em] shadow-2xl transition-all relative overflow-hidden group ${
                    !canPlay ? 'bg-slate-800 opacity-70 cursor-not-allowed' : 'bg-gradient-to-r from-yellow-600 via-yellow-400 to-yellow-600 active:translate-y-1'
                }`}
            >
                {isSpinning && <div className="absolute inset-0 bg-white/10 animate-pulse"></div>}
                <span className="relative z-10 drop-shadow-md text-sm">
                  {isSpinning ? 'ВРАЩЕНИЕ...' : (balance < bet ? 'ПОПОЛНИТЕ СЧЕТ' : 'ИГРАТЬ')}
                </span>
            </button>
        </div>
      </div>

      <style>{`
        .clip-pointer {
          clip-path: polygon(0% 0%, 100% 0%, 100% 70%, 50% 100%, 0% 70%);
        }
      `}</style>
    </div>
  );
};

export default WheelOfFortune;
