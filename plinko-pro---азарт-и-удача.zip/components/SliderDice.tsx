
import React, { useState } from 'react';

interface SliderDiceProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const SliderDice: React.FC<SliderDiceProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [chance, setChance] = useState(50);
  const [roll, setRoll] = useState<number | null>(null);
  const [isRolling, setIsRolling] = useState(false);

  const play = () => {
    if (balance < bet || isRolling) return;
    onBalanceChange(-bet);
    setIsRolling(true);
    setRoll(null);

    setTimeout(() => {
      const result = parseFloat((Math.random() * 100).toFixed(2));
      setRoll(result);
      setIsRolling(false);

      if (result <= chance) {
        const multiplier = (97 / chance);
        onBalanceChange(Math.floor(bet * multiplier));
      }
    }, 600);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#0a0a1a] text-white p-6">
      <div className="flex justify-between items-center mb-10">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-indigo-500 uppercase">SLIDER DICE</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className={`text-6xl font-black transition-all ${roll === null ? 'text-slate-700' : roll <= chance ? 'text-green-400 scale-110' : 'text-red-500'}`}>
          {roll !== null ? roll.toFixed(2) : '??.??'}
        </div>
        
        <div className="w-full max-w-sm mt-12 bg-slate-800 h-4 rounded-full relative overflow-hidden border border-slate-700">
           <div className="h-full bg-green-600 transition-all" style={{ width: `${chance}%` }}></div>
        </div>
        
        <input 
          type="range" 
          min="1" max="95" 
          value={chance} 
          onChange={e => setChance(parseInt(e.target.value))}
          className="w-full max-w-sm mt-4 accent-indigo-500"
        />
        
        <div className="mt-4 flex justify-between w-full max-w-sm text-xs font-black uppercase text-slate-500">
           <span>Шанс: {chance}%</span>
           <span>Множитель: x{(97/chance).toFixed(2)}</span>
        </div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4">
        <div className="flex items-center gap-4 bg-black/40 p-4 rounded-2xl border border-slate-800">
           <input 
             type="number" 
             value={bet} 
             onChange={e => setBet(parseInt(e.target.value) || 0)} 
             className="bg-transparent text-xl font-black outline-none w-full"
             placeholder="Сумма ставки"
           />
           <button onClick={() => setBet(Math.floor(balance))} className="text-[10px] font-black bg-slate-800 px-3 py-1 rounded">MAX</button>
        </div>
        <button onClick={play} disabled={isRolling || balance < bet} className="w-full h-16 bg-indigo-600 rounded-2xl font-black uppercase shadow-xl active:scale-95">КИНУТЬ КОСТЬ</button>
      </div>
    </div>
  );
};

export default SliderDice;
