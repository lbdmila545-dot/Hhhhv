
import React, { useState } from 'react';

interface GoalProps {
  balance: number;
  onBalanceChange: (amount: number) => void;
  onBack: () => void;
}

const Goal: React.FC<GoalProps> = ({ balance, onBalanceChange, onBack }) => {
  const [bet, setBet] = useState(10);
  const [isShooting, setIsShooting] = useState(false);
  const [result, setResult] = useState<string>('');

  const shoot = (pos: number) => {
    if (balance < bet || isShooting) return;
    onBalanceChange(-bet);
    setIsShooting(true);
    setResult('');

    setTimeout(() => {
      const keeperPos = Math.floor(Math.random() * 5);
      if (pos !== keeperPos) {
        onBalanceChange(bet * 4.5);
        setResult('ГООООЛ! x4.5');
      } else {
        setResult('СЕЙВ!');
      }
      setIsShooting(false);
    }, 800);
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#051a05] text-white p-6">
      <div className="flex justify-between items-center mb-8">
        <button onClick={onBack} className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center"><i className="fas fa-arrow-left"></i></button>
        <span className="font-black italic text-green-500 uppercase">GOAL PRO</span>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-12">
         <div className="w-full h-48 bg-slate-900/50 border-4 border-white/40 rounded-t-3xl relative overflow-hidden flex items-end justify-around pb-4">
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_#fff_1px,_transparent_1px)] bg-[size:10px_10px]"></div>
            {[0,1,2,3,4].map(i => (
               <button 
                key={i} 
                onClick={() => shoot(i)}
                disabled={isShooting}
                className="w-12 h-12 rounded-full bg-white/10 border-2 border-white/20 hover:bg-green-500/40 hover:border-green-400 transition-all z-10"
               >
                  <i className="fas fa-bullseye opacity-40"></i>
               </button>
            ))}
         </div>
         <div className="text-4xl font-black italic uppercase text-green-400">{result}</div>
      </div>

      <div className="bg-slate-900 p-8 rounded-t-[40px] space-y-4">
         <div className="text-[10px] text-slate-500 font-black uppercase text-center mb-2">ВЫБЕРИТЕ ЗОНУ УДАРА</div>
         <input type="number" value={bet} onChange={e => setBet(parseInt(e.target.value))} className="w-full bg-black/40 p-4 rounded-2xl border border-slate-800 text-center font-black" />
         <div className="text-[9px] text-center text-slate-500">УСПЕШНЫЙ ГОЛ УМНОЖАЕТ СТАВКУ НА 4.5</div>
      </div>
    </div>
  );
};

export default Goal;
