
import React, { useState, useEffect, useCallback } from 'react';
import PlinkoBoard from './components/PlinkoBoard.tsx';
import BetControls from './components/BetControls.tsx';
import Header from './components/Header.tsx';
import Lobby from './components/Lobby.tsx';
import AppleOfFortune from './components/AppleOfFortune.tsx';
import WheelOfFortune from './components/WheelOfFortune.tsx';
import Slots from './components/Slots.tsx';
import CoinFlip from './components/CoinFlip.tsx';
import Mines from './components/Mines.tsx';
import Crash from './components/Crash.tsx';
import DiceGame from './components/DiceGame.tsx';
import HigherLower from './components/HigherLower.tsx';
import SupportChat from './components/SupportChat.tsx';
import Roulette from './components/Roulette.tsx';
import Blackjack from './components/Blackjack.tsx';
import Baccarat from './components/Baccarat.tsx';
import Tower from './components/Tower.tsx';
import Cases from './components/Cases.tsx';
import SliderDice from './components/SliderDice.tsx';
import Crypt from './components/Crypt.tsx';
import Goal from './components/Goal.tsx';
import Plumber from './components/Plumber.tsx';
import ProfileModal from './components/ProfileModal.tsx';
import LeaderboardModal from './components/LeaderboardModal.tsx';
import QuestsModal from './components/QuestsModal.tsx';
import SecurityProvider from './components/SecurityProvider.tsx';
import ScratchCards from './components/ScratchCards.tsx';
import Thimbles from './components/Thimbles.tsx';
import Keno from './components/Keno.tsx';
import Penalty from './components/Penalty.tsx';
import Stairs from './components/Stairs.tsx';
import RockPaperScissors from './components/RockPaperScissors.tsx';
import Limbo from './components/Limbo.tsx';

import { GameState, UserProfile, GameView, Achievement, Quest } from './types.ts';
import { INITIAL_BALANCE, MIN_BET } from './constants.ts';

const SECURE_STORAGE_KEY = 'plinko_pro_v9_final';

const INITIAL_QUESTS: Quest[] = [
  { id: 'win_big', title: 'Крупный куш', target: 50000, current: 0, reward: 5000, isClaimed: false },
  { id: 'play_10', title: 'Игрок', target: 10, current: 0, reward: 2000, isClaimed: false }
];

const App: React.FC = () => {
  const [state, setState] = useState<GameState>({
    balance: INITIAL_BALANCE,
    secureHash: '',
    betAmount: MIN_BET,
    isAutoPlaying: false,
    history: [],
    lastWin: null,
    user: null,
    currentView: 'LOBBY',
    customPromos: [],
    achievements: [],
    quests: INITIAL_QUESTS,
    soundEnabled: true
  });

  const [modals, setModals] = useState({ profile: false, leaderboard: false, quests: false });
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const saved = localStorage.getItem(SECURE_STORAGE_KEY);
    if (saved) setState(prev => ({ ...prev, ...JSON.parse(saved) }));
    else {
      setState(prev => ({ 
        ...prev, 
        user: { 
            email: `player_${Math.floor(Math.random()*1000)}@1xbet.ru`, 
            id: Math.random().toString(36).substr(2,6).toUpperCase(), 
            isRegistered: true, 
            level: 1, 
            xp: 0, 
            totalWon: 0 
        } 
      }));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(SECURE_STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const handleBalanceUpdate = useCallback((amount: number, gameName?: string) => {
    setState(prev => {
        const newBalance = Math.max(0, prev.balance + amount);
        const newHistory = gameName ? [{ 
            id: Math.random().toString(36).substr(2,9), 
            game: gameName, 
            amount: Math.abs(amount), 
            type: amount > 0 ? 'win' as const : 'lose' as const, 
            date: new Date() 
        }, ...prev.history].slice(0, 20) : prev.history;

        return { 
          ...prev, 
          balance: newBalance,
          history: newHistory,
          user: prev.user ? { 
            ...prev.user, 
            xp: prev.user.xp + Math.abs(amount/10), 
            totalWon: amount > 0 ? prev.user.totalWon + amount : prev.user.totalWon 
          } : null
        };
    });
  }, []);

  const setView = (view: GameView) => setState(p => ({ ...p, currentView: view }));

  return (
    <SecurityProvider onBan={() => {}} banInfo={undefined}>
      <div className="flex flex-col h-[100dvh] w-full max-w-md mx-auto bg-slate-950 overflow-hidden relative shadow-2xl">
        <Header balance={state.balance} user={state.user} onHome={() => setView('LOBBY')} onProfile={() => setModals(m => ({ ...m, profile: true }))} isOnline={isOnline} />
        
        <main className="flex-1 flex flex-col min-h-0 relative overflow-hidden bg-slate-950">
          {state.currentView === 'LOBBY' && <Lobby onSelectGame={setView} onClaimBonus={() => handleBalanceUpdate(100000)} onDaily={() => setModals(m => ({ ...m, quests: true }))} onShowLeaderboard={() => setModals(m => ({ ...m, leaderboard: true }))} />}
          
          {state.currentView === 'PLINKO' && (
            <div className="flex flex-col h-full w-full">
              <div className="p-2 flex-shrink-0"><button onClick={() => setView('LOBBY')} className="bg-slate-800 px-4 py-2 rounded-xl text-xs font-bold active:scale-95 transition-transform"><i className="fas fa-arrow-left mr-2"></i>Назад</button></div>
              <div className="game-canvas-container flex-1 min-h-0 overflow-hidden flex items-center justify-center">
                <PlinkoBoard onWin={(m, b) => handleBalanceUpdate(Math.floor(m * b), 'PLINKO')} shouldDrop={() => { if(state.balance < state.betAmount) return false; handleBalanceUpdate(-state.betAmount); return true; }} currentBet={state.betAmount} />
              </div>
              <BetControls betAmount={state.betAmount} onBetChange={a => setState(p => ({ ...p, betAmount: a }))} onPlay={() => true} isAutoPlaying={state.isAutoPlaying} onToggleAuto={() => setState(p => ({ ...p, isAutoPlaying: !p.isAutoPlaying }))} balance={state.balance} />
            </div>
          )}

          {/* Полная логика рендеринга всех игр */}
          {state.currentView === 'ROULETTE' && <Roulette balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'ROULETTE')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'CRASH' && <Crash balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'CRASH')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'MINES' && <Mines balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'MINES')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'SLOTS' && <Slots balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'SLOTS')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'APPLE' && <AppleOfFortune balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'APPLE')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'COINFLIP' && <CoinFlip balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'COINFLIP')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'DICE' && <DiceGame balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'DICE')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'CARDS' && <HigherLower balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'CARDS')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'BLACKJACK' && <Blackjack balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'BLACKJACK')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'BACCARAT' && <Baccarat balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'BACCARAT')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'TOWER' && <Tower balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'TOWER')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'CASES' && <Cases balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'CASES')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'SLIDERDICE' && <SliderDice balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'SLIDERDICE')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'CRYPT' && <Crypt balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'CRYPT')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'GOAL' && <Goal balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'GOAL')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'PLUMBER' && <Plumber balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'PLUMBER')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'SCRATCH' && <ScratchCards balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'SCRATCH')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'KENO' && <Keno balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'KENO')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'THIMBLES' && <Thimbles balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'THIMBLES')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'STAIRS' && <Stairs balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'STAIRS')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'PENALTY' && <Penalty balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'PENALTY')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'RPS' && <RockPaperScissors balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'RPS')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'LIMBO' && <Limbo balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'LIMBO')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'WHEEL' && <WheelOfFortune balance={state.balance} onBalanceChange={amt => handleBalanceUpdate(amt, 'WHEEL')} onBack={() => setView('LOBBY')} />}
          {state.currentView === 'CHAT' && <SupportChat onBack={() => setView('LOBBY')} isOnline={isOnline} />}
        </main>

        <footer className="h-16 bg-slate-900 border-t border-slate-800 flex items-center justify-around pb-safe flex-shrink-0 z-[100]">
          <button onClick={() => setView('LOBBY')} className={`flex flex-col items-center gap-1 ${state.currentView === 'LOBBY' ? 'text-blue-500' : 'text-slate-500'}`}><i className="fas fa-home"></i><span className="text-[10px] font-bold">Лобби</span></button>
          <button onClick={() => setModals(m => ({ ...m, profile: true }))} className="flex flex-col items-center gap-1 text-slate-500"><i className="fas fa-user"></i><span className="text-[10px] font-bold">Профиль</span></button>
          <button onClick={() => handleBalanceUpdate(50000)} className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center -mt-6 border-4 border-slate-950 shadow-xl active:scale-90 transition-transform"><i className="fas fa-plus text-white"></i></button>
          <button onClick={() => setModals(m => ({ ...m, leaderboard: true }))} className="flex flex-col items-center gap-1 text-slate-500"><i className="fas fa-trophy"></i><span className="text-[10px] font-bold">Топ</span></button>
          <button onClick={() => setModals(m => ({ ...m, quests: true }))} className="flex flex-col items-center gap-1 text-slate-500"><i className="fas fa-gift"></i><span className="text-[10px] font-bold">Бонус</span></button>
        </footer>

        {modals.profile && <ProfileModal user={state.user} balance={state.balance} history={state.history} onClose={() => setModals(m => ({ ...m, profile: false }))} onDeposit={() => handleBalanceUpdate(10000)} />}
        {modals.leaderboard && <LeaderboardModal onClose={() => setModals(m => ({ ...m, leaderboard: false }))} />}
        {modals.quests && <QuestsModal quests={state.quests} onClaim={(id, r) => { handleBalanceUpdate(r); setState(p => ({ ...p, quests: p.quests.map(q => q.id === id ? { ...q, isClaimed: true } : q) })) }} onClose={() => setModals(m => ({ ...m, quests: false }))} />}
      </div>
    </SecurityProvider>
  );
};

export default App;
