
export type GameView = 'LOBBY' | 'PLINKO' | 'APPLE' | 'WHEEL' | 'SLOTS' | 'COINFLIP' | 'MINES' | 'CHAT' | 'CRASH' | 'DICE' | 'CARDS' | 'SCRATCH' | 'THIMBLES' | 'KENO' | 'PENALTY' | 'STAIRS' | 'RPS' | 'LIMBO' | 'ROULETTE' | 'BLACKJACK' | 'BACCARAT' | 'TOWER' | 'CASES' | 'SLIDERDICE' | 'CRYPT' | 'GOAL' | 'PLUMBER';

export interface BanInfo {
  isBanned: boolean;
  reason: string;
  expiresAt: number | 'PERMANENT';
  violations: number;
  hwid: string;
}

export interface HistoryItem {
  id: string;
  game: string;
  amount: number;
  type: 'win' | 'lose';
  date: Date;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  isUnlocked: boolean;
}

export interface Quest {
  id: string;
  title: string;
  target: number;
  current: number;
  reward: number;
  isClaimed: boolean;
}

export interface CustomPromo {
  code: string;
  reward: number;
  uses: number;
}

export interface UserProfile {
  email: string;
  id: string;
  isRegistered: boolean;
  level: number;
  xp: number;
  totalWon: number;
}

export interface GameState {
  balance: number;
  secureHash: string; 
  betAmount: number;
  isAutoPlaying: boolean;
  history: HistoryItem[];
  lastWin: number | null;
  user: UserProfile | null;
  currentView: GameView;
  customPromos: CustomPromo[];
  achievements: Achievement[];
  quests: Quest[];
  soundEnabled: boolean;
  banInfo?: BanInfo;
}

export interface Ball {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  betValue: number;
  color: string;
}

export interface Pin {
  x: number;
  y: number;
  radius: number;
}

export interface Multiplier {
  value: number;
  color: string;
  label: string;
}
